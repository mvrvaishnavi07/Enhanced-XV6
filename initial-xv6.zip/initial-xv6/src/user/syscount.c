#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/syscall.h"

int main(int argc, char *argv[]) {
  if (argc < 3) {
    fprintf(2, "Usage: syscount <mask> command [args]\n");
    exit(1);
  }

  int mask = atoi(argv[1]);

  int pid = fork();
  if (pid < 0) {
    fprintf(2, "fork failed\n");
    exit(1);
  }

  if (pid == 0) {
    // Child process
    exec(argv[2], &argv[2]);
    fprintf(2, "exec failed\n");
    exit(1);
  } else {
    // Parent process
    wait(0);
    int count = getSysCount(mask);
    char *syscall_name = "unknown";

    // Map syscall number to name
    if (mask == (1 << SYS_write)) syscall_name = "write";
    else if (mask == (1 << SYS_open)) syscall_name = "open";
    else if (mask == (1 << SYS_read)) syscall_name = "read";
    else if (mask == (1 << SYS_close)) syscall_name = "close";
    else if (mask == (1 << SYS_fork)) syscall_name = "fork";
    else if (mask == (1 << SYS_exit)) syscall_name = "exit";
    else if (mask == (1 << SYS_wait)) syscall_name = "wait";
    else if (mask == (1 << SYS_pipe)) syscall_name = "pipe";
    else if (mask == (1 << SYS_kill)) syscall_name = "kill";
    else if (mask == (1 << SYS_exec)) syscall_name = "exec";
    else if (mask == (1 << SYS_fstat)) syscall_name = "fstat";
    else if (mask == (1 << SYS_chdir)) syscall_name = "chdir";
    else if (mask == (1 << SYS_dup)) syscall_name = "dup";
    else if (mask == (1 << SYS_getpid)) syscall_name = "getpid";
    else if (mask == (1 << SYS_sbrk)) syscall_name = "sbrk";
    else if (mask == (1 << SYS_sleep)) syscall_name = "sleep";
    else if (mask == (1 << SYS_uptime)) syscall_name = "uptime";
    else if (mask == (1 << SYS_mknod)) syscall_name = "mknod";
    else if (mask == (1 << SYS_unlink)) syscall_name = "unlink";
    else if (mask == (1 << SYS_link)) syscall_name = "link";
    else if (mask == (1 << SYS_mkdir)) syscall_name = "mkdir";
    else if (mask == (1 << SYS_waitx)) syscall_name = "waitx";
    else if (mask == (1 << SYS_getSysCount)) syscall_name = "getSysCount";

    // Output the result
    printf("PID %d called %s %d times\n", pid, syscall_name, count);
    exit(0);
  }
}
