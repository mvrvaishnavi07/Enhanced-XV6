
user/_syscount:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/syscall.h"

int main(int argc, char *argv[]) {
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	1800                	addi	s0,sp,48
  if (argc < 3) {
   e:	4789                	li	a5,2
  10:	02a7c063          	blt	a5,a0,30 <main+0x30>
    fprintf(2, "Usage: syscount <mask> command [args]\n");
  14:	00001597          	auipc	a1,0x1
  18:	ad458593          	addi	a1,a1,-1324 # ae8 <malloc+0x1ac>
  1c:	4509                	li	a0,2
  1e:	00001097          	auipc	ra,0x1
  22:	832080e7          	jalr	-1998(ra) # 850 <fprintf>
    exit(1);
  26:	4505                	li	a0,1
  28:	00000097          	auipc	ra,0x0
  2c:	4b6080e7          	jalr	1206(ra) # 4de <exit>
  30:	84ae                	mv	s1,a1
  }

  int mask = atoi(argv[1]);
  32:	6588                	ld	a0,8(a1)
  34:	00000097          	auipc	ra,0x0
  38:	3ae080e7          	jalr	942(ra) # 3e2 <atoi>
  3c:	89aa                	mv	s3,a0

  int pid = fork();
  3e:	00000097          	auipc	ra,0x0
  42:	498080e7          	jalr	1176(ra) # 4d6 <fork>
  46:	892a                	mv	s2,a0
  if (pid < 0) {
  48:	02054863          	bltz	a0,78 <main+0x78>
    fprintf(2, "fork failed\n");
    exit(1);
  }

  if (pid == 0) {
  4c:	e521                	bnez	a0,94 <main+0x94>
    // Child process
    exec(argv[2], &argv[2]);
  4e:	01048593          	addi	a1,s1,16
  52:	6888                	ld	a0,16(s1)
  54:	00000097          	auipc	ra,0x0
  58:	4c2080e7          	jalr	1218(ra) # 516 <exec>
    fprintf(2, "exec failed\n");
  5c:	00001597          	auipc	a1,0x1
  60:	ac458593          	addi	a1,a1,-1340 # b20 <malloc+0x1e4>
  64:	4509                	li	a0,2
  66:	00000097          	auipc	ra,0x0
  6a:	7ea080e7          	jalr	2026(ra) # 850 <fprintf>
    exit(1);
  6e:	4505                	li	a0,1
  70:	00000097          	auipc	ra,0x0
  74:	46e080e7          	jalr	1134(ra) # 4de <exit>
    fprintf(2, "fork failed\n");
  78:	00001597          	auipc	a1,0x1
  7c:	a9858593          	addi	a1,a1,-1384 # b10 <malloc+0x1d4>
  80:	4509                	li	a0,2
  82:	00000097          	auipc	ra,0x0
  86:	7ce080e7          	jalr	1998(ra) # 850 <fprintf>
    exit(1);
  8a:	4505                	li	a0,1
  8c:	00000097          	auipc	ra,0x0
  90:	452080e7          	jalr	1106(ra) # 4de <exit>
  } else {
    // Parent process
    wait(0);
  94:	4501                	li	a0,0
  96:	00000097          	auipc	ra,0x0
  9a:	450080e7          	jalr	1104(ra) # 4e6 <wait>
    int count = getSysCount(mask);
  9e:	854e                	mv	a0,s3
  a0:	00000097          	auipc	ra,0x0
  a4:	4e6080e7          	jalr	1254(ra) # 586 <getSysCount>
  a8:	86aa                	mv	a3,a0
    char *syscall_name = "unknown";

    // Map syscall number to name
    if (mask == (1 << SYS_write)) syscall_name = "write";
  aa:	67c1                	lui	a5,0x10
  ac:	0af98a63          	beq	s3,a5,160 <main+0x160>
    else if (mask == (1 << SYS_open)) syscall_name = "open";
  b0:	67a1                	lui	a5,0x8
  b2:	0cf98963          	beq	s3,a5,184 <main+0x184>
    else if (mask == (1 << SYS_read)) syscall_name = "read";
  b6:	02000793          	li	a5,32
  ba:	0cf98a63          	beq	s3,a5,18e <main+0x18e>
    else if (mask == (1 << SYS_close)) syscall_name = "close";
  be:	002007b7          	lui	a5,0x200
  c2:	0cf98b63          	beq	s3,a5,198 <main+0x198>
    else if (mask == (1 << SYS_fork)) syscall_name = "fork";
  c6:	4789                	li	a5,2
  c8:	0cf98d63          	beq	s3,a5,1a2 <main+0x1a2>
    else if (mask == (1 << SYS_exit)) syscall_name = "exit";
  cc:	4791                	li	a5,4
  ce:	0cf98f63          	beq	s3,a5,1ac <main+0x1ac>
    else if (mask == (1 << SYS_wait)) syscall_name = "wait";
  d2:	47a1                	li	a5,8
  d4:	0ef98163          	beq	s3,a5,1b6 <main+0x1b6>
    else if (mask == (1 << SYS_pipe)) syscall_name = "pipe";
  d8:	47c1                	li	a5,16
  da:	0ef98363          	beq	s3,a5,1c0 <main+0x1c0>
    else if (mask == (1 << SYS_kill)) syscall_name = "kill";
  de:	04000793          	li	a5,64
  e2:	0ef98463          	beq	s3,a5,1ca <main+0x1ca>
    else if (mask == (1 << SYS_exec)) syscall_name = "exec";
  e6:	08000793          	li	a5,128
  ea:	0ef98563          	beq	s3,a5,1d4 <main+0x1d4>
    else if (mask == (1 << SYS_fstat)) syscall_name = "fstat";
  ee:	10000793          	li	a5,256
  f2:	0ef98663          	beq	s3,a5,1de <main+0x1de>
    else if (mask == (1 << SYS_chdir)) syscall_name = "chdir";
  f6:	20000793          	li	a5,512
  fa:	0ef98763          	beq	s3,a5,1e8 <main+0x1e8>
    else if (mask == (1 << SYS_dup)) syscall_name = "dup";
  fe:	40000793          	li	a5,1024
 102:	0ef98863          	beq	s3,a5,1f2 <main+0x1f2>
    else if (mask == (1 << SYS_getpid)) syscall_name = "getpid";
 106:	8009879b          	addiw	a5,s3,-2048
 10a:	cbed                	beqz	a5,1fc <main+0x1fc>
    else if (mask == (1 << SYS_sbrk)) syscall_name = "sbrk";
 10c:	6785                	lui	a5,0x1
 10e:	0ef98c63          	beq	s3,a5,206 <main+0x206>
    else if (mask == (1 << SYS_sleep)) syscall_name = "sleep";
 112:	6789                	lui	a5,0x2
 114:	0ef98e63          	beq	s3,a5,210 <main+0x210>
    else if (mask == (1 << SYS_uptime)) syscall_name = "uptime";
 118:	6791                	lui	a5,0x4
 11a:	10f98063          	beq	s3,a5,21a <main+0x21a>
    else if (mask == (1 << SYS_mknod)) syscall_name = "mknod";
 11e:	000207b7          	lui	a5,0x20
 122:	10f98163          	beq	s3,a5,224 <main+0x224>
    else if (mask == (1 << SYS_unlink)) syscall_name = "unlink";
 126:	000407b7          	lui	a5,0x40
 12a:	10f98263          	beq	s3,a5,22e <main+0x22e>
    else if (mask == (1 << SYS_link)) syscall_name = "link";
 12e:	000807b7          	lui	a5,0x80
 132:	10f98363          	beq	s3,a5,238 <main+0x238>
    else if (mask == (1 << SYS_mkdir)) syscall_name = "mkdir";
 136:	001007b7          	lui	a5,0x100
 13a:	10f98463          	beq	s3,a5,242 <main+0x242>
    else if (mask == (1 << SYS_waitx)) syscall_name = "waitx";
 13e:	004007b7          	lui	a5,0x400
 142:	10f98563          	beq	s3,a5,24c <main+0x24c>
    else if (mask == (1 << SYS_getSysCount)) syscall_name = "getSysCount";
 146:	008007b7          	lui	a5,0x800
    char *syscall_name = "unknown";
 14a:	00001617          	auipc	a2,0x1
 14e:	8de60613          	addi	a2,a2,-1826 # a28 <malloc+0xec>
    else if (mask == (1 << SYS_getSysCount)) syscall_name = "getSysCount";
 152:	00f99b63          	bne	s3,a5,168 <main+0x168>
 156:	00001617          	auipc	a2,0x1
 15a:	98260613          	addi	a2,a2,-1662 # ad8 <malloc+0x19c>
 15e:	a029                	j	168 <main+0x168>
    if (mask == (1 << SYS_write)) syscall_name = "write";
 160:	00001617          	auipc	a2,0x1
 164:	8d060613          	addi	a2,a2,-1840 # a30 <malloc+0xf4>

    // Output the result
    printf("PID %d called %s %d times\n", pid, syscall_name, count);
 168:	85ca                	mv	a1,s2
 16a:	00001517          	auipc	a0,0x1
 16e:	9c650513          	addi	a0,a0,-1594 # b30 <malloc+0x1f4>
 172:	00000097          	auipc	ra,0x0
 176:	70c080e7          	jalr	1804(ra) # 87e <printf>
    exit(0);
 17a:	4501                	li	a0,0
 17c:	00000097          	auipc	ra,0x0
 180:	362080e7          	jalr	866(ra) # 4de <exit>
    else if (mask == (1 << SYS_open)) syscall_name = "open";
 184:	00001617          	auipc	a2,0x1
 188:	8b460613          	addi	a2,a2,-1868 # a38 <malloc+0xfc>
 18c:	bff1                	j	168 <main+0x168>
    else if (mask == (1 << SYS_read)) syscall_name = "read";
 18e:	00001617          	auipc	a2,0x1
 192:	8b260613          	addi	a2,a2,-1870 # a40 <malloc+0x104>
 196:	bfc9                	j	168 <main+0x168>
    else if (mask == (1 << SYS_close)) syscall_name = "close";
 198:	00001617          	auipc	a2,0x1
 19c:	8b060613          	addi	a2,a2,-1872 # a48 <malloc+0x10c>
 1a0:	b7e1                	j	168 <main+0x168>
    else if (mask == (1 << SYS_fork)) syscall_name = "fork";
 1a2:	00001617          	auipc	a2,0x1
 1a6:	8ae60613          	addi	a2,a2,-1874 # a50 <malloc+0x114>
 1aa:	bf7d                	j	168 <main+0x168>
    else if (mask == (1 << SYS_exit)) syscall_name = "exit";
 1ac:	00001617          	auipc	a2,0x1
 1b0:	8ac60613          	addi	a2,a2,-1876 # a58 <malloc+0x11c>
 1b4:	bf55                	j	168 <main+0x168>
    else if (mask == (1 << SYS_wait)) syscall_name = "wait";
 1b6:	00001617          	auipc	a2,0x1
 1ba:	8aa60613          	addi	a2,a2,-1878 # a60 <malloc+0x124>
 1be:	b76d                	j	168 <main+0x168>
    else if (mask == (1 << SYS_pipe)) syscall_name = "pipe";
 1c0:	00001617          	auipc	a2,0x1
 1c4:	8a860613          	addi	a2,a2,-1880 # a68 <malloc+0x12c>
 1c8:	b745                	j	168 <main+0x168>
    else if (mask == (1 << SYS_kill)) syscall_name = "kill";
 1ca:	00001617          	auipc	a2,0x1
 1ce:	8a660613          	addi	a2,a2,-1882 # a70 <malloc+0x134>
 1d2:	bf59                	j	168 <main+0x168>
    else if (mask == (1 << SYS_exec)) syscall_name = "exec";
 1d4:	00001617          	auipc	a2,0x1
 1d8:	8a460613          	addi	a2,a2,-1884 # a78 <malloc+0x13c>
 1dc:	b771                	j	168 <main+0x168>
    else if (mask == (1 << SYS_fstat)) syscall_name = "fstat";
 1de:	00001617          	auipc	a2,0x1
 1e2:	8a260613          	addi	a2,a2,-1886 # a80 <malloc+0x144>
 1e6:	b749                	j	168 <main+0x168>
    else if (mask == (1 << SYS_chdir)) syscall_name = "chdir";
 1e8:	00001617          	auipc	a2,0x1
 1ec:	8a060613          	addi	a2,a2,-1888 # a88 <malloc+0x14c>
 1f0:	bfa5                	j	168 <main+0x168>
    else if (mask == (1 << SYS_dup)) syscall_name = "dup";
 1f2:	00001617          	auipc	a2,0x1
 1f6:	89e60613          	addi	a2,a2,-1890 # a90 <malloc+0x154>
 1fa:	b7bd                	j	168 <main+0x168>
    else if (mask == (1 << SYS_getpid)) syscall_name = "getpid";
 1fc:	00001617          	auipc	a2,0x1
 200:	89c60613          	addi	a2,a2,-1892 # a98 <malloc+0x15c>
 204:	b795                	j	168 <main+0x168>
    else if (mask == (1 << SYS_sbrk)) syscall_name = "sbrk";
 206:	00001617          	auipc	a2,0x1
 20a:	89a60613          	addi	a2,a2,-1894 # aa0 <malloc+0x164>
 20e:	bfa9                	j	168 <main+0x168>
    else if (mask == (1 << SYS_sleep)) syscall_name = "sleep";
 210:	00001617          	auipc	a2,0x1
 214:	89860613          	addi	a2,a2,-1896 # aa8 <malloc+0x16c>
 218:	bf81                	j	168 <main+0x168>
    else if (mask == (1 << SYS_uptime)) syscall_name = "uptime";
 21a:	00001617          	auipc	a2,0x1
 21e:	89660613          	addi	a2,a2,-1898 # ab0 <malloc+0x174>
 222:	b799                	j	168 <main+0x168>
    else if (mask == (1 << SYS_mknod)) syscall_name = "mknod";
 224:	00001617          	auipc	a2,0x1
 228:	89460613          	addi	a2,a2,-1900 # ab8 <malloc+0x17c>
 22c:	bf35                	j	168 <main+0x168>
    else if (mask == (1 << SYS_unlink)) syscall_name = "unlink";
 22e:	00001617          	auipc	a2,0x1
 232:	89260613          	addi	a2,a2,-1902 # ac0 <malloc+0x184>
 236:	bf0d                	j	168 <main+0x168>
    else if (mask == (1 << SYS_link)) syscall_name = "link";
 238:	00001617          	auipc	a2,0x1
 23c:	89060613          	addi	a2,a2,-1904 # ac8 <malloc+0x18c>
 240:	b725                	j	168 <main+0x168>
    else if (mask == (1 << SYS_mkdir)) syscall_name = "mkdir";
 242:	00001617          	auipc	a2,0x1
 246:	88e60613          	addi	a2,a2,-1906 # ad0 <malloc+0x194>
 24a:	bf39                	j	168 <main+0x168>
    else if (mask == (1 << SYS_waitx)) syscall_name = "waitx";
 24c:	00000617          	auipc	a2,0x0
 250:	7d460613          	addi	a2,a2,2004 # a20 <malloc+0xe4>
 254:	bf11                	j	168 <main+0x168>

0000000000000256 <_main>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
_main()
{
 256:	1141                	addi	sp,sp,-16
 258:	e406                	sd	ra,8(sp)
 25a:	e022                	sd	s0,0(sp)
 25c:	0800                	addi	s0,sp,16
  extern int main();
  main();
 25e:	00000097          	auipc	ra,0x0
 262:	da2080e7          	jalr	-606(ra) # 0 <main>
  exit(0);
 266:	4501                	li	a0,0
 268:	00000097          	auipc	ra,0x0
 26c:	276080e7          	jalr	630(ra) # 4de <exit>

0000000000000270 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 270:	1141                	addi	sp,sp,-16
 272:	e422                	sd	s0,8(sp)
 274:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 276:	87aa                	mv	a5,a0
 278:	0585                	addi	a1,a1,1
 27a:	0785                	addi	a5,a5,1
 27c:	fff5c703          	lbu	a4,-1(a1)
 280:	fee78fa3          	sb	a4,-1(a5) # 7fffff <base+0x7fefef>
 284:	fb75                	bnez	a4,278 <strcpy+0x8>
    ;
  return os;
}
 286:	6422                	ld	s0,8(sp)
 288:	0141                	addi	sp,sp,16
 28a:	8082                	ret

000000000000028c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28c:	1141                	addi	sp,sp,-16
 28e:	e422                	sd	s0,8(sp)
 290:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 292:	00054783          	lbu	a5,0(a0)
 296:	cb91                	beqz	a5,2aa <strcmp+0x1e>
 298:	0005c703          	lbu	a4,0(a1)
 29c:	00f71763          	bne	a4,a5,2aa <strcmp+0x1e>
    p++, q++;
 2a0:	0505                	addi	a0,a0,1
 2a2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a4:	00054783          	lbu	a5,0(a0)
 2a8:	fbe5                	bnez	a5,298 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 2aa:	0005c503          	lbu	a0,0(a1)
}
 2ae:	40a7853b          	subw	a0,a5,a0
 2b2:	6422                	ld	s0,8(sp)
 2b4:	0141                	addi	sp,sp,16
 2b6:	8082                	ret

00000000000002b8 <strlen>:

uint
strlen(const char *s)
{
 2b8:	1141                	addi	sp,sp,-16
 2ba:	e422                	sd	s0,8(sp)
 2bc:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2be:	00054783          	lbu	a5,0(a0)
 2c2:	cf91                	beqz	a5,2de <strlen+0x26>
 2c4:	0505                	addi	a0,a0,1
 2c6:	87aa                	mv	a5,a0
 2c8:	4685                	li	a3,1
 2ca:	9e89                	subw	a3,a3,a0
 2cc:	00f6853b          	addw	a0,a3,a5
 2d0:	0785                	addi	a5,a5,1
 2d2:	fff7c703          	lbu	a4,-1(a5)
 2d6:	fb7d                	bnez	a4,2cc <strlen+0x14>
    ;
  return n;
}
 2d8:	6422                	ld	s0,8(sp)
 2da:	0141                	addi	sp,sp,16
 2dc:	8082                	ret
  for(n = 0; s[n]; n++)
 2de:	4501                	li	a0,0
 2e0:	bfe5                	j	2d8 <strlen+0x20>

00000000000002e2 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e2:	1141                	addi	sp,sp,-16
 2e4:	e422                	sd	s0,8(sp)
 2e6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2e8:	ca19                	beqz	a2,2fe <memset+0x1c>
 2ea:	87aa                	mv	a5,a0
 2ec:	1602                	slli	a2,a2,0x20
 2ee:	9201                	srli	a2,a2,0x20
 2f0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2f4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2f8:	0785                	addi	a5,a5,1
 2fa:	fee79de3          	bne	a5,a4,2f4 <memset+0x12>
  }
  return dst;
}
 2fe:	6422                	ld	s0,8(sp)
 300:	0141                	addi	sp,sp,16
 302:	8082                	ret

0000000000000304 <strchr>:

char*
strchr(const char *s, char c)
{
 304:	1141                	addi	sp,sp,-16
 306:	e422                	sd	s0,8(sp)
 308:	0800                	addi	s0,sp,16
  for(; *s; s++)
 30a:	00054783          	lbu	a5,0(a0)
 30e:	cb99                	beqz	a5,324 <strchr+0x20>
    if(*s == c)
 310:	00f58763          	beq	a1,a5,31e <strchr+0x1a>
  for(; *s; s++)
 314:	0505                	addi	a0,a0,1
 316:	00054783          	lbu	a5,0(a0)
 31a:	fbfd                	bnez	a5,310 <strchr+0xc>
      return (char*)s;
  return 0;
 31c:	4501                	li	a0,0
}
 31e:	6422                	ld	s0,8(sp)
 320:	0141                	addi	sp,sp,16
 322:	8082                	ret
  return 0;
 324:	4501                	li	a0,0
 326:	bfe5                	j	31e <strchr+0x1a>

0000000000000328 <gets>:

char*
gets(char *buf, int max)
{
 328:	711d                	addi	sp,sp,-96
 32a:	ec86                	sd	ra,88(sp)
 32c:	e8a2                	sd	s0,80(sp)
 32e:	e4a6                	sd	s1,72(sp)
 330:	e0ca                	sd	s2,64(sp)
 332:	fc4e                	sd	s3,56(sp)
 334:	f852                	sd	s4,48(sp)
 336:	f456                	sd	s5,40(sp)
 338:	f05a                	sd	s6,32(sp)
 33a:	ec5e                	sd	s7,24(sp)
 33c:	1080                	addi	s0,sp,96
 33e:	8baa                	mv	s7,a0
 340:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 342:	892a                	mv	s2,a0
 344:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 346:	4aa9                	li	s5,10
 348:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 34a:	89a6                	mv	s3,s1
 34c:	2485                	addiw	s1,s1,1
 34e:	0344d863          	bge	s1,s4,37e <gets+0x56>
    cc = read(0, &c, 1);
 352:	4605                	li	a2,1
 354:	faf40593          	addi	a1,s0,-81
 358:	4501                	li	a0,0
 35a:	00000097          	auipc	ra,0x0
 35e:	19c080e7          	jalr	412(ra) # 4f6 <read>
    if(cc < 1)
 362:	00a05e63          	blez	a0,37e <gets+0x56>
    buf[i++] = c;
 366:	faf44783          	lbu	a5,-81(s0)
 36a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 36e:	01578763          	beq	a5,s5,37c <gets+0x54>
 372:	0905                	addi	s2,s2,1
 374:	fd679be3          	bne	a5,s6,34a <gets+0x22>
  for(i=0; i+1 < max; ){
 378:	89a6                	mv	s3,s1
 37a:	a011                	j	37e <gets+0x56>
 37c:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 37e:	99de                	add	s3,s3,s7
 380:	00098023          	sb	zero,0(s3)
  return buf;
}
 384:	855e                	mv	a0,s7
 386:	60e6                	ld	ra,88(sp)
 388:	6446                	ld	s0,80(sp)
 38a:	64a6                	ld	s1,72(sp)
 38c:	6906                	ld	s2,64(sp)
 38e:	79e2                	ld	s3,56(sp)
 390:	7a42                	ld	s4,48(sp)
 392:	7aa2                	ld	s5,40(sp)
 394:	7b02                	ld	s6,32(sp)
 396:	6be2                	ld	s7,24(sp)
 398:	6125                	addi	sp,sp,96
 39a:	8082                	ret

000000000000039c <stat>:

int
stat(const char *n, struct stat *st)
{
 39c:	1101                	addi	sp,sp,-32
 39e:	ec06                	sd	ra,24(sp)
 3a0:	e822                	sd	s0,16(sp)
 3a2:	e426                	sd	s1,8(sp)
 3a4:	e04a                	sd	s2,0(sp)
 3a6:	1000                	addi	s0,sp,32
 3a8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3aa:	4581                	li	a1,0
 3ac:	00000097          	auipc	ra,0x0
 3b0:	172080e7          	jalr	370(ra) # 51e <open>
  if(fd < 0)
 3b4:	02054563          	bltz	a0,3de <stat+0x42>
 3b8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3ba:	85ca                	mv	a1,s2
 3bc:	00000097          	auipc	ra,0x0
 3c0:	17a080e7          	jalr	378(ra) # 536 <fstat>
 3c4:	892a                	mv	s2,a0
  close(fd);
 3c6:	8526                	mv	a0,s1
 3c8:	00000097          	auipc	ra,0x0
 3cc:	13e080e7          	jalr	318(ra) # 506 <close>
  return r;
}
 3d0:	854a                	mv	a0,s2
 3d2:	60e2                	ld	ra,24(sp)
 3d4:	6442                	ld	s0,16(sp)
 3d6:	64a2                	ld	s1,8(sp)
 3d8:	6902                	ld	s2,0(sp)
 3da:	6105                	addi	sp,sp,32
 3dc:	8082                	ret
    return -1;
 3de:	597d                	li	s2,-1
 3e0:	bfc5                	j	3d0 <stat+0x34>

00000000000003e2 <atoi>:

int
atoi(const char *s)
{
 3e2:	1141                	addi	sp,sp,-16
 3e4:	e422                	sd	s0,8(sp)
 3e6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3e8:	00054603          	lbu	a2,0(a0)
 3ec:	fd06079b          	addiw	a5,a2,-48
 3f0:	0ff7f793          	andi	a5,a5,255
 3f4:	4725                	li	a4,9
 3f6:	02f76963          	bltu	a4,a5,428 <atoi+0x46>
 3fa:	86aa                	mv	a3,a0
  n = 0;
 3fc:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 3fe:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 400:	0685                	addi	a3,a3,1
 402:	0025179b          	slliw	a5,a0,0x2
 406:	9fa9                	addw	a5,a5,a0
 408:	0017979b          	slliw	a5,a5,0x1
 40c:	9fb1                	addw	a5,a5,a2
 40e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 412:	0006c603          	lbu	a2,0(a3)
 416:	fd06071b          	addiw	a4,a2,-48
 41a:	0ff77713          	andi	a4,a4,255
 41e:	fee5f1e3          	bgeu	a1,a4,400 <atoi+0x1e>
  return n;
}
 422:	6422                	ld	s0,8(sp)
 424:	0141                	addi	sp,sp,16
 426:	8082                	ret
  n = 0;
 428:	4501                	li	a0,0
 42a:	bfe5                	j	422 <atoi+0x40>

000000000000042c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 42c:	1141                	addi	sp,sp,-16
 42e:	e422                	sd	s0,8(sp)
 430:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 432:	02b57463          	bgeu	a0,a1,45a <memmove+0x2e>
    while(n-- > 0)
 436:	00c05f63          	blez	a2,454 <memmove+0x28>
 43a:	1602                	slli	a2,a2,0x20
 43c:	9201                	srli	a2,a2,0x20
 43e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 442:	872a                	mv	a4,a0
      *dst++ = *src++;
 444:	0585                	addi	a1,a1,1
 446:	0705                	addi	a4,a4,1
 448:	fff5c683          	lbu	a3,-1(a1)
 44c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 450:	fee79ae3          	bne	a5,a4,444 <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 454:	6422                	ld	s0,8(sp)
 456:	0141                	addi	sp,sp,16
 458:	8082                	ret
    dst += n;
 45a:	00c50733          	add	a4,a0,a2
    src += n;
 45e:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 460:	fec05ae3          	blez	a2,454 <memmove+0x28>
 464:	fff6079b          	addiw	a5,a2,-1
 468:	1782                	slli	a5,a5,0x20
 46a:	9381                	srli	a5,a5,0x20
 46c:	fff7c793          	not	a5,a5
 470:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 472:	15fd                	addi	a1,a1,-1
 474:	177d                	addi	a4,a4,-1
 476:	0005c683          	lbu	a3,0(a1)
 47a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 47e:	fee79ae3          	bne	a5,a4,472 <memmove+0x46>
 482:	bfc9                	j	454 <memmove+0x28>

0000000000000484 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 484:	1141                	addi	sp,sp,-16
 486:	e422                	sd	s0,8(sp)
 488:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 48a:	ca05                	beqz	a2,4ba <memcmp+0x36>
 48c:	fff6069b          	addiw	a3,a2,-1
 490:	1682                	slli	a3,a3,0x20
 492:	9281                	srli	a3,a3,0x20
 494:	0685                	addi	a3,a3,1
 496:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 498:	00054783          	lbu	a5,0(a0)
 49c:	0005c703          	lbu	a4,0(a1)
 4a0:	00e79863          	bne	a5,a4,4b0 <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 4a4:	0505                	addi	a0,a0,1
    p2++;
 4a6:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4a8:	fed518e3          	bne	a0,a3,498 <memcmp+0x14>
  }
  return 0;
 4ac:	4501                	li	a0,0
 4ae:	a019                	j	4b4 <memcmp+0x30>
      return *p1 - *p2;
 4b0:	40e7853b          	subw	a0,a5,a4
}
 4b4:	6422                	ld	s0,8(sp)
 4b6:	0141                	addi	sp,sp,16
 4b8:	8082                	ret
  return 0;
 4ba:	4501                	li	a0,0
 4bc:	bfe5                	j	4b4 <memcmp+0x30>

00000000000004be <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4be:	1141                	addi	sp,sp,-16
 4c0:	e406                	sd	ra,8(sp)
 4c2:	e022                	sd	s0,0(sp)
 4c4:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4c6:	00000097          	auipc	ra,0x0
 4ca:	f66080e7          	jalr	-154(ra) # 42c <memmove>
}
 4ce:	60a2                	ld	ra,8(sp)
 4d0:	6402                	ld	s0,0(sp)
 4d2:	0141                	addi	sp,sp,16
 4d4:	8082                	ret

00000000000004d6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4d6:	4885                	li	a7,1
 ecall
 4d8:	00000073          	ecall
 ret
 4dc:	8082                	ret

00000000000004de <exit>:
.global exit
exit:
 li a7, SYS_exit
 4de:	4889                	li	a7,2
 ecall
 4e0:	00000073          	ecall
 ret
 4e4:	8082                	ret

00000000000004e6 <wait>:
.global wait
wait:
 li a7, SYS_wait
 4e6:	488d                	li	a7,3
 ecall
 4e8:	00000073          	ecall
 ret
 4ec:	8082                	ret

00000000000004ee <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4ee:	4891                	li	a7,4
 ecall
 4f0:	00000073          	ecall
 ret
 4f4:	8082                	ret

00000000000004f6 <read>:
.global read
read:
 li a7, SYS_read
 4f6:	4895                	li	a7,5
 ecall
 4f8:	00000073          	ecall
 ret
 4fc:	8082                	ret

00000000000004fe <write>:
.global write
write:
 li a7, SYS_write
 4fe:	48c1                	li	a7,16
 ecall
 500:	00000073          	ecall
 ret
 504:	8082                	ret

0000000000000506 <close>:
.global close
close:
 li a7, SYS_close
 506:	48d5                	li	a7,21
 ecall
 508:	00000073          	ecall
 ret
 50c:	8082                	ret

000000000000050e <kill>:
.global kill
kill:
 li a7, SYS_kill
 50e:	4899                	li	a7,6
 ecall
 510:	00000073          	ecall
 ret
 514:	8082                	ret

0000000000000516 <exec>:
.global exec
exec:
 li a7, SYS_exec
 516:	489d                	li	a7,7
 ecall
 518:	00000073          	ecall
 ret
 51c:	8082                	ret

000000000000051e <open>:
.global open
open:
 li a7, SYS_open
 51e:	48bd                	li	a7,15
 ecall
 520:	00000073          	ecall
 ret
 524:	8082                	ret

0000000000000526 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 526:	48c5                	li	a7,17
 ecall
 528:	00000073          	ecall
 ret
 52c:	8082                	ret

000000000000052e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 52e:	48c9                	li	a7,18
 ecall
 530:	00000073          	ecall
 ret
 534:	8082                	ret

0000000000000536 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 536:	48a1                	li	a7,8
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <link>:
.global link
link:
 li a7, SYS_link
 53e:	48cd                	li	a7,19
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 546:	48d1                	li	a7,20
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 54e:	48a5                	li	a7,9
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <dup>:
.global dup
dup:
 li a7, SYS_dup
 556:	48a9                	li	a7,10
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 55e:	48ad                	li	a7,11
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 566:	48b1                	li	a7,12
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 56e:	48b5                	li	a7,13
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 576:	48b9                	li	a7,14
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <waitx>:
.global waitx
waitx:
 li a7, SYS_waitx
 57e:	48d9                	li	a7,22
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <getSysCount>:
.global getSysCount
getSysCount:
 li a7, SYS_getSysCount
 586:	48dd                	li	a7,23
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 58e:	48e1                	li	a7,24
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 596:	48e5                	li	a7,25
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <settickets>:
.global settickets
settickets:
 li a7, SYS_settickets
 59e:	48e9                	li	a7,26
 ecall
 5a0:	00000073          	ecall
 ret
 5a4:	8082                	ret

00000000000005a6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5a6:	1101                	addi	sp,sp,-32
 5a8:	ec06                	sd	ra,24(sp)
 5aa:	e822                	sd	s0,16(sp)
 5ac:	1000                	addi	s0,sp,32
 5ae:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5b2:	4605                	li	a2,1
 5b4:	fef40593          	addi	a1,s0,-17
 5b8:	00000097          	auipc	ra,0x0
 5bc:	f46080e7          	jalr	-186(ra) # 4fe <write>
}
 5c0:	60e2                	ld	ra,24(sp)
 5c2:	6442                	ld	s0,16(sp)
 5c4:	6105                	addi	sp,sp,32
 5c6:	8082                	ret

00000000000005c8 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 5c8:	7139                	addi	sp,sp,-64
 5ca:	fc06                	sd	ra,56(sp)
 5cc:	f822                	sd	s0,48(sp)
 5ce:	f426                	sd	s1,40(sp)
 5d0:	f04a                	sd	s2,32(sp)
 5d2:	ec4e                	sd	s3,24(sp)
 5d4:	0080                	addi	s0,sp,64
 5d6:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5d8:	c299                	beqz	a3,5de <printint+0x16>
 5da:	0805c863          	bltz	a1,66a <printint+0xa2>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5de:	2581                	sext.w	a1,a1
  neg = 0;
 5e0:	4881                	li	a7,0
 5e2:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
 5e6:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 5e8:	2601                	sext.w	a2,a2
 5ea:	00000517          	auipc	a0,0x0
 5ee:	56e50513          	addi	a0,a0,1390 # b58 <digits>
 5f2:	883a                	mv	a6,a4
 5f4:	2705                	addiw	a4,a4,1
 5f6:	02c5f7bb          	remuw	a5,a1,a2
 5fa:	1782                	slli	a5,a5,0x20
 5fc:	9381                	srli	a5,a5,0x20
 5fe:	97aa                	add	a5,a5,a0
 600:	0007c783          	lbu	a5,0(a5)
 604:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 608:	0005879b          	sext.w	a5,a1
 60c:	02c5d5bb          	divuw	a1,a1,a2
 610:	0685                	addi	a3,a3,1
 612:	fec7f0e3          	bgeu	a5,a2,5f2 <printint+0x2a>
  if(neg)
 616:	00088b63          	beqz	a7,62c <printint+0x64>
    buf[i++] = '-';
 61a:	fd040793          	addi	a5,s0,-48
 61e:	973e                	add	a4,a4,a5
 620:	02d00793          	li	a5,45
 624:	fef70823          	sb	a5,-16(a4)
 628:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 62c:	02e05863          	blez	a4,65c <printint+0x94>
 630:	fc040793          	addi	a5,s0,-64
 634:	00e78933          	add	s2,a5,a4
 638:	fff78993          	addi	s3,a5,-1
 63c:	99ba                	add	s3,s3,a4
 63e:	377d                	addiw	a4,a4,-1
 640:	1702                	slli	a4,a4,0x20
 642:	9301                	srli	a4,a4,0x20
 644:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 648:	fff94583          	lbu	a1,-1(s2)
 64c:	8526                	mv	a0,s1
 64e:	00000097          	auipc	ra,0x0
 652:	f58080e7          	jalr	-168(ra) # 5a6 <putc>
  while(--i >= 0)
 656:	197d                	addi	s2,s2,-1
 658:	ff3918e3          	bne	s2,s3,648 <printint+0x80>
}
 65c:	70e2                	ld	ra,56(sp)
 65e:	7442                	ld	s0,48(sp)
 660:	74a2                	ld	s1,40(sp)
 662:	7902                	ld	s2,32(sp)
 664:	69e2                	ld	s3,24(sp)
 666:	6121                	addi	sp,sp,64
 668:	8082                	ret
    x = -xx;
 66a:	40b005bb          	negw	a1,a1
    neg = 1;
 66e:	4885                	li	a7,1
    x = -xx;
 670:	bf8d                	j	5e2 <printint+0x1a>

0000000000000672 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 672:	7119                	addi	sp,sp,-128
 674:	fc86                	sd	ra,120(sp)
 676:	f8a2                	sd	s0,112(sp)
 678:	f4a6                	sd	s1,104(sp)
 67a:	f0ca                	sd	s2,96(sp)
 67c:	ecce                	sd	s3,88(sp)
 67e:	e8d2                	sd	s4,80(sp)
 680:	e4d6                	sd	s5,72(sp)
 682:	e0da                	sd	s6,64(sp)
 684:	fc5e                	sd	s7,56(sp)
 686:	f862                	sd	s8,48(sp)
 688:	f466                	sd	s9,40(sp)
 68a:	f06a                	sd	s10,32(sp)
 68c:	ec6e                	sd	s11,24(sp)
 68e:	0100                	addi	s0,sp,128
  char *s;
  int c, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 690:	0005c903          	lbu	s2,0(a1)
 694:	18090f63          	beqz	s2,832 <vprintf+0x1c0>
 698:	8aaa                	mv	s5,a0
 69a:	8b32                	mv	s6,a2
 69c:	00158493          	addi	s1,a1,1
  state = 0;
 6a0:	4981                	li	s3,0
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 6a2:	02500a13          	li	s4,37
      if(c == 'd'){
 6a6:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c == 'l') {
 6aa:	06c00c93          	li	s9,108
        printint(fd, va_arg(ap, uint64), 10, 0);
      } else if(c == 'x') {
 6ae:	07800d13          	li	s10,120
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c == 'p') {
 6b2:	07000d93          	li	s11,112
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6b6:	00000b97          	auipc	s7,0x0
 6ba:	4a2b8b93          	addi	s7,s7,1186 # b58 <digits>
 6be:	a839                	j	6dc <vprintf+0x6a>
        putc(fd, c);
 6c0:	85ca                	mv	a1,s2
 6c2:	8556                	mv	a0,s5
 6c4:	00000097          	auipc	ra,0x0
 6c8:	ee2080e7          	jalr	-286(ra) # 5a6 <putc>
 6cc:	a019                	j	6d2 <vprintf+0x60>
    } else if(state == '%'){
 6ce:	01498f63          	beq	s3,s4,6ec <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 6d2:	0485                	addi	s1,s1,1
 6d4:	fff4c903          	lbu	s2,-1(s1)
 6d8:	14090d63          	beqz	s2,832 <vprintf+0x1c0>
    c = fmt[i] & 0xff;
 6dc:	0009079b          	sext.w	a5,s2
    if(state == 0){
 6e0:	fe0997e3          	bnez	s3,6ce <vprintf+0x5c>
      if(c == '%'){
 6e4:	fd479ee3          	bne	a5,s4,6c0 <vprintf+0x4e>
        state = '%';
 6e8:	89be                	mv	s3,a5
 6ea:	b7e5                	j	6d2 <vprintf+0x60>
      if(c == 'd'){
 6ec:	05878063          	beq	a5,s8,72c <vprintf+0xba>
      } else if(c == 'l') {
 6f0:	05978c63          	beq	a5,s9,748 <vprintf+0xd6>
      } else if(c == 'x') {
 6f4:	07a78863          	beq	a5,s10,764 <vprintf+0xf2>
      } else if(c == 'p') {
 6f8:	09b78463          	beq	a5,s11,780 <vprintf+0x10e>
        printptr(fd, va_arg(ap, uint64));
      } else if(c == 's'){
 6fc:	07300713          	li	a4,115
 700:	0ce78663          	beq	a5,a4,7cc <vprintf+0x15a>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 704:	06300713          	li	a4,99
 708:	0ee78e63          	beq	a5,a4,804 <vprintf+0x192>
        putc(fd, va_arg(ap, uint));
      } else if(c == '%'){
 70c:	11478863          	beq	a5,s4,81c <vprintf+0x1aa>
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 710:	85d2                	mv	a1,s4
 712:	8556                	mv	a0,s5
 714:	00000097          	auipc	ra,0x0
 718:	e92080e7          	jalr	-366(ra) # 5a6 <putc>
        putc(fd, c);
 71c:	85ca                	mv	a1,s2
 71e:	8556                	mv	a0,s5
 720:	00000097          	auipc	ra,0x0
 724:	e86080e7          	jalr	-378(ra) # 5a6 <putc>
      }
      state = 0;
 728:	4981                	li	s3,0
 72a:	b765                	j	6d2 <vprintf+0x60>
        printint(fd, va_arg(ap, int), 10, 1);
 72c:	008b0913          	addi	s2,s6,8
 730:	4685                	li	a3,1
 732:	4629                	li	a2,10
 734:	000b2583          	lw	a1,0(s6)
 738:	8556                	mv	a0,s5
 73a:	00000097          	auipc	ra,0x0
 73e:	e8e080e7          	jalr	-370(ra) # 5c8 <printint>
 742:	8b4a                	mv	s6,s2
      state = 0;
 744:	4981                	li	s3,0
 746:	b771                	j	6d2 <vprintf+0x60>
        printint(fd, va_arg(ap, uint64), 10, 0);
 748:	008b0913          	addi	s2,s6,8
 74c:	4681                	li	a3,0
 74e:	4629                	li	a2,10
 750:	000b2583          	lw	a1,0(s6)
 754:	8556                	mv	a0,s5
 756:	00000097          	auipc	ra,0x0
 75a:	e72080e7          	jalr	-398(ra) # 5c8 <printint>
 75e:	8b4a                	mv	s6,s2
      state = 0;
 760:	4981                	li	s3,0
 762:	bf85                	j	6d2 <vprintf+0x60>
        printint(fd, va_arg(ap, int), 16, 0);
 764:	008b0913          	addi	s2,s6,8
 768:	4681                	li	a3,0
 76a:	4641                	li	a2,16
 76c:	000b2583          	lw	a1,0(s6)
 770:	8556                	mv	a0,s5
 772:	00000097          	auipc	ra,0x0
 776:	e56080e7          	jalr	-426(ra) # 5c8 <printint>
 77a:	8b4a                	mv	s6,s2
      state = 0;
 77c:	4981                	li	s3,0
 77e:	bf91                	j	6d2 <vprintf+0x60>
        printptr(fd, va_arg(ap, uint64));
 780:	008b0793          	addi	a5,s6,8
 784:	f8f43423          	sd	a5,-120(s0)
 788:	000b3983          	ld	s3,0(s6)
  putc(fd, '0');
 78c:	03000593          	li	a1,48
 790:	8556                	mv	a0,s5
 792:	00000097          	auipc	ra,0x0
 796:	e14080e7          	jalr	-492(ra) # 5a6 <putc>
  putc(fd, 'x');
 79a:	85ea                	mv	a1,s10
 79c:	8556                	mv	a0,s5
 79e:	00000097          	auipc	ra,0x0
 7a2:	e08080e7          	jalr	-504(ra) # 5a6 <putc>
 7a6:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7a8:	03c9d793          	srli	a5,s3,0x3c
 7ac:	97de                	add	a5,a5,s7
 7ae:	0007c583          	lbu	a1,0(a5)
 7b2:	8556                	mv	a0,s5
 7b4:	00000097          	auipc	ra,0x0
 7b8:	df2080e7          	jalr	-526(ra) # 5a6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7bc:	0992                	slli	s3,s3,0x4
 7be:	397d                	addiw	s2,s2,-1
 7c0:	fe0914e3          	bnez	s2,7a8 <vprintf+0x136>
        printptr(fd, va_arg(ap, uint64));
 7c4:	f8843b03          	ld	s6,-120(s0)
      state = 0;
 7c8:	4981                	li	s3,0
 7ca:	b721                	j	6d2 <vprintf+0x60>
        s = va_arg(ap, char*);
 7cc:	008b0993          	addi	s3,s6,8
 7d0:	000b3903          	ld	s2,0(s6)
        if(s == 0)
 7d4:	02090163          	beqz	s2,7f6 <vprintf+0x184>
        while(*s != 0){
 7d8:	00094583          	lbu	a1,0(s2)
 7dc:	c9a1                	beqz	a1,82c <vprintf+0x1ba>
          putc(fd, *s);
 7de:	8556                	mv	a0,s5
 7e0:	00000097          	auipc	ra,0x0
 7e4:	dc6080e7          	jalr	-570(ra) # 5a6 <putc>
          s++;
 7e8:	0905                	addi	s2,s2,1
        while(*s != 0){
 7ea:	00094583          	lbu	a1,0(s2)
 7ee:	f9e5                	bnez	a1,7de <vprintf+0x16c>
        s = va_arg(ap, char*);
 7f0:	8b4e                	mv	s6,s3
      state = 0;
 7f2:	4981                	li	s3,0
 7f4:	bdf9                	j	6d2 <vprintf+0x60>
          s = "(null)";
 7f6:	00000917          	auipc	s2,0x0
 7fa:	35a90913          	addi	s2,s2,858 # b50 <malloc+0x214>
        while(*s != 0){
 7fe:	02800593          	li	a1,40
 802:	bff1                	j	7de <vprintf+0x16c>
        putc(fd, va_arg(ap, uint));
 804:	008b0913          	addi	s2,s6,8
 808:	000b4583          	lbu	a1,0(s6)
 80c:	8556                	mv	a0,s5
 80e:	00000097          	auipc	ra,0x0
 812:	d98080e7          	jalr	-616(ra) # 5a6 <putc>
 816:	8b4a                	mv	s6,s2
      state = 0;
 818:	4981                	li	s3,0
 81a:	bd65                	j	6d2 <vprintf+0x60>
        putc(fd, c);
 81c:	85d2                	mv	a1,s4
 81e:	8556                	mv	a0,s5
 820:	00000097          	auipc	ra,0x0
 824:	d86080e7          	jalr	-634(ra) # 5a6 <putc>
      state = 0;
 828:	4981                	li	s3,0
 82a:	b565                	j	6d2 <vprintf+0x60>
        s = va_arg(ap, char*);
 82c:	8b4e                	mv	s6,s3
      state = 0;
 82e:	4981                	li	s3,0
 830:	b54d                	j	6d2 <vprintf+0x60>
    }
  }
}
 832:	70e6                	ld	ra,120(sp)
 834:	7446                	ld	s0,112(sp)
 836:	74a6                	ld	s1,104(sp)
 838:	7906                	ld	s2,96(sp)
 83a:	69e6                	ld	s3,88(sp)
 83c:	6a46                	ld	s4,80(sp)
 83e:	6aa6                	ld	s5,72(sp)
 840:	6b06                	ld	s6,64(sp)
 842:	7be2                	ld	s7,56(sp)
 844:	7c42                	ld	s8,48(sp)
 846:	7ca2                	ld	s9,40(sp)
 848:	7d02                	ld	s10,32(sp)
 84a:	6de2                	ld	s11,24(sp)
 84c:	6109                	addi	sp,sp,128
 84e:	8082                	ret

0000000000000850 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 850:	715d                	addi	sp,sp,-80
 852:	ec06                	sd	ra,24(sp)
 854:	e822                	sd	s0,16(sp)
 856:	1000                	addi	s0,sp,32
 858:	e010                	sd	a2,0(s0)
 85a:	e414                	sd	a3,8(s0)
 85c:	e818                	sd	a4,16(s0)
 85e:	ec1c                	sd	a5,24(s0)
 860:	03043023          	sd	a6,32(s0)
 864:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 868:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 86c:	8622                	mv	a2,s0
 86e:	00000097          	auipc	ra,0x0
 872:	e04080e7          	jalr	-508(ra) # 672 <vprintf>
}
 876:	60e2                	ld	ra,24(sp)
 878:	6442                	ld	s0,16(sp)
 87a:	6161                	addi	sp,sp,80
 87c:	8082                	ret

000000000000087e <printf>:

void
printf(const char *fmt, ...)
{
 87e:	711d                	addi	sp,sp,-96
 880:	ec06                	sd	ra,24(sp)
 882:	e822                	sd	s0,16(sp)
 884:	1000                	addi	s0,sp,32
 886:	e40c                	sd	a1,8(s0)
 888:	e810                	sd	a2,16(s0)
 88a:	ec14                	sd	a3,24(s0)
 88c:	f018                	sd	a4,32(s0)
 88e:	f41c                	sd	a5,40(s0)
 890:	03043823          	sd	a6,48(s0)
 894:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 898:	00840613          	addi	a2,s0,8
 89c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8a0:	85aa                	mv	a1,a0
 8a2:	4505                	li	a0,1
 8a4:	00000097          	auipc	ra,0x0
 8a8:	dce080e7          	jalr	-562(ra) # 672 <vprintf>
}
 8ac:	60e2                	ld	ra,24(sp)
 8ae:	6442                	ld	s0,16(sp)
 8b0:	6125                	addi	sp,sp,96
 8b2:	8082                	ret

00000000000008b4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8b4:	1141                	addi	sp,sp,-16
 8b6:	e422                	sd	s0,8(sp)
 8b8:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8ba:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8be:	00000797          	auipc	a5,0x0
 8c2:	7427b783          	ld	a5,1858(a5) # 1000 <freep>
 8c6:	a805                	j	8f6 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 8c8:	4618                	lw	a4,8(a2)
 8ca:	9db9                	addw	a1,a1,a4
 8cc:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8d0:	6398                	ld	a4,0(a5)
 8d2:	6318                	ld	a4,0(a4)
 8d4:	fee53823          	sd	a4,-16(a0)
 8d8:	a091                	j	91c <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 8da:	ff852703          	lw	a4,-8(a0)
 8de:	9e39                	addw	a2,a2,a4
 8e0:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 8e2:	ff053703          	ld	a4,-16(a0)
 8e6:	e398                	sd	a4,0(a5)
 8e8:	a099                	j	92e <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8ea:	6398                	ld	a4,0(a5)
 8ec:	00e7e463          	bltu	a5,a4,8f4 <free+0x40>
 8f0:	00e6ea63          	bltu	a3,a4,904 <free+0x50>
{
 8f4:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8f6:	fed7fae3          	bgeu	a5,a3,8ea <free+0x36>
 8fa:	6398                	ld	a4,0(a5)
 8fc:	00e6e463          	bltu	a3,a4,904 <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 900:	fee7eae3          	bltu	a5,a4,8f4 <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 904:	ff852583          	lw	a1,-8(a0)
 908:	6390                	ld	a2,0(a5)
 90a:	02059713          	slli	a4,a1,0x20
 90e:	9301                	srli	a4,a4,0x20
 910:	0712                	slli	a4,a4,0x4
 912:	9736                	add	a4,a4,a3
 914:	fae60ae3          	beq	a2,a4,8c8 <free+0x14>
    bp->s.ptr = p->s.ptr;
 918:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 91c:	4790                	lw	a2,8(a5)
 91e:	02061713          	slli	a4,a2,0x20
 922:	9301                	srli	a4,a4,0x20
 924:	0712                	slli	a4,a4,0x4
 926:	973e                	add	a4,a4,a5
 928:	fae689e3          	beq	a3,a4,8da <free+0x26>
  } else
    p->s.ptr = bp;
 92c:	e394                	sd	a3,0(a5)
  freep = p;
 92e:	00000717          	auipc	a4,0x0
 932:	6cf73923          	sd	a5,1746(a4) # 1000 <freep>
}
 936:	6422                	ld	s0,8(sp)
 938:	0141                	addi	sp,sp,16
 93a:	8082                	ret

000000000000093c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 93c:	7139                	addi	sp,sp,-64
 93e:	fc06                	sd	ra,56(sp)
 940:	f822                	sd	s0,48(sp)
 942:	f426                	sd	s1,40(sp)
 944:	f04a                	sd	s2,32(sp)
 946:	ec4e                	sd	s3,24(sp)
 948:	e852                	sd	s4,16(sp)
 94a:	e456                	sd	s5,8(sp)
 94c:	e05a                	sd	s6,0(sp)
 94e:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 950:	02051493          	slli	s1,a0,0x20
 954:	9081                	srli	s1,s1,0x20
 956:	04bd                	addi	s1,s1,15
 958:	8091                	srli	s1,s1,0x4
 95a:	0014899b          	addiw	s3,s1,1
 95e:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 960:	00000517          	auipc	a0,0x0
 964:	6a053503          	ld	a0,1696(a0) # 1000 <freep>
 968:	c515                	beqz	a0,994 <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 96a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 96c:	4798                	lw	a4,8(a5)
 96e:	02977f63          	bgeu	a4,s1,9ac <malloc+0x70>
 972:	8a4e                	mv	s4,s3
 974:	0009871b          	sext.w	a4,s3
 978:	6685                	lui	a3,0x1
 97a:	00d77363          	bgeu	a4,a3,980 <malloc+0x44>
 97e:	6a05                	lui	s4,0x1
 980:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 984:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 988:	00000917          	auipc	s2,0x0
 98c:	67890913          	addi	s2,s2,1656 # 1000 <freep>
  if(p == (char*)-1)
 990:	5afd                	li	s5,-1
 992:	a88d                	j	a04 <malloc+0xc8>
    base.s.ptr = freep = prevp = &base;
 994:	00000797          	auipc	a5,0x0
 998:	67c78793          	addi	a5,a5,1660 # 1010 <base>
 99c:	00000717          	auipc	a4,0x0
 9a0:	66f73223          	sd	a5,1636(a4) # 1000 <freep>
 9a4:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9a6:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9aa:	b7e1                	j	972 <malloc+0x36>
      if(p->s.size == nunits)
 9ac:	02e48b63          	beq	s1,a4,9e2 <malloc+0xa6>
        p->s.size -= nunits;
 9b0:	4137073b          	subw	a4,a4,s3
 9b4:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9b6:	1702                	slli	a4,a4,0x20
 9b8:	9301                	srli	a4,a4,0x20
 9ba:	0712                	slli	a4,a4,0x4
 9bc:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9be:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9c2:	00000717          	auipc	a4,0x0
 9c6:	62a73f23          	sd	a0,1598(a4) # 1000 <freep>
      return (void*)(p + 1);
 9ca:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 9ce:	70e2                	ld	ra,56(sp)
 9d0:	7442                	ld	s0,48(sp)
 9d2:	74a2                	ld	s1,40(sp)
 9d4:	7902                	ld	s2,32(sp)
 9d6:	69e2                	ld	s3,24(sp)
 9d8:	6a42                	ld	s4,16(sp)
 9da:	6aa2                	ld	s5,8(sp)
 9dc:	6b02                	ld	s6,0(sp)
 9de:	6121                	addi	sp,sp,64
 9e0:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 9e2:	6398                	ld	a4,0(a5)
 9e4:	e118                	sd	a4,0(a0)
 9e6:	bff1                	j	9c2 <malloc+0x86>
  hp->s.size = nu;
 9e8:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9ec:	0541                	addi	a0,a0,16
 9ee:	00000097          	auipc	ra,0x0
 9f2:	ec6080e7          	jalr	-314(ra) # 8b4 <free>
  return freep;
 9f6:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 9fa:	d971                	beqz	a0,9ce <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9fc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9fe:	4798                	lw	a4,8(a5)
 a00:	fa9776e3          	bgeu	a4,s1,9ac <malloc+0x70>
    if(p == freep)
 a04:	00093703          	ld	a4,0(s2)
 a08:	853e                	mv	a0,a5
 a0a:	fef719e3          	bne	a4,a5,9fc <malloc+0xc0>
  p = sbrk(nu * sizeof(Header));
 a0e:	8552                	mv	a0,s4
 a10:	00000097          	auipc	ra,0x0
 a14:	b56080e7          	jalr	-1194(ra) # 566 <sbrk>
  if(p == (char*)-1)
 a18:	fd5518e3          	bne	a0,s5,9e8 <malloc+0xac>
        return 0;
 a1c:	4501                	li	a0,0
 a1e:	bf45                	j	9ce <malloc+0x92>
