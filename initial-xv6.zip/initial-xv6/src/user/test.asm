
user/_test:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <usless_work>:
#include "kernel/riscv.h"
#include "user/user.h"
#pragma GCC push_options
#pragma GCC optimize ("O0") // Causing wierd errors of moving things here and there

void usless_work() {
   0:	1101                	addi	sp,sp,-32
   2:	ec22                	sd	s0,24(sp)
   4:	1000                	addi	s0,sp,32
    for (int i = 0; i < 1000 * 900000; i++) {
   6:	fe042623          	sw	zero,-20(s0)
   a:	a039                	j	18 <usless_work+0x18>
        asm volatile("nop"); // avoid compiler optimizing away loop
   c:	0001                	nop
    for (int i = 0; i < 1000 * 900000; i++) {
   e:	fec42783          	lw	a5,-20(s0)
  12:	2785                	addiw	a5,a5,1
  14:	fef42623          	sw	a5,-20(s0)
  18:	fec42783          	lw	a5,-20(s0)
  1c:	0007871b          	sext.w	a4,a5
  20:	35a4f7b7          	lui	a5,0x35a4f
  24:	8ff78793          	addi	a5,a5,-1793 # 35a4e8ff <base+0x35a4d8ef>
  28:	fee7d2e3          	bge	a5,a4,c <usless_work+0xc>
    }
}
  2c:	0001                	nop
  2e:	0001                	nop
  30:	6462                	ld	s0,24(sp)
  32:	6105                	addi	sp,sp,32
  34:	8082                	ret

0000000000000036 <test0>:


void test0(){
  36:	1101                	addi	sp,sp,-32
  38:	ec06                	sd	ra,24(sp)
  3a:	e822                	sd	s0,16(sp)
  3c:	1000                	addi	s0,sp,32
    settickets(600);// So that parent will get the higher priority and the forks can run at once
  3e:	25800513          	li	a0,600
  42:	00000097          	auipc	ra,0x0
  46:	6a6080e7          	jalr	1702(ra) # 6e8 <settickets>
    printf("TEST 0\n"); // To check the randomness
  4a:	00001517          	auipc	a0,0x1
  4e:	b2650513          	addi	a0,a0,-1242 # b70 <malloc+0xea>
  52:	00001097          	auipc	ra,0x1
  56:	976080e7          	jalr	-1674(ra) # 9c8 <printf>
    int prog1_tickets = 1;
  5a:	4785                	li	a5,1
  5c:	fef42623          	sw	a5,-20(s0)
    int prog2_tickets = 4;
  60:	4791                	li	a5,4
  62:	fef42423          	sw	a5,-24(s0)
    int prog3_tickets = 16;
  66:	47c1                	li	a5,16
  68:	fef42223          	sw	a5,-28(s0)
    int prog4_tickets = 8;
  6c:	47a1                	li	a5,8
  6e:	fef42023          	sw	a5,-32(s0)
    printf("Child 1 has %d tickets.\nChild 2 has %d tickets\nChild 3 has %d tickets\nChild 4 has %d tickets\n",
  72:	fe042703          	lw	a4,-32(s0)
  76:	fe442683          	lw	a3,-28(s0)
  7a:	fe842603          	lw	a2,-24(s0)
  7e:	fec42783          	lw	a5,-20(s0)
  82:	85be                	mv	a1,a5
  84:	00001517          	auipc	a0,0x1
  88:	af450513          	addi	a0,a0,-1292 # b78 <malloc+0xf2>
  8c:	00001097          	auipc	ra,0x1
  90:	93c080e7          	jalr	-1732(ra) # 9c8 <printf>
           prog1_tickets, prog2_tickets, prog3_tickets, prog4_tickets);

    if (fork() == 0) {
  94:	00000097          	auipc	ra,0x0
  98:	58c080e7          	jalr	1420(ra) # 620 <fork>
  9c:	87aa                	mv	a5,a0
  9e:	e7b1                	bnez	a5,ea <test0+0xb4>
        settickets(prog1_tickets);
  a0:	fec42783          	lw	a5,-20(s0)
  a4:	853e                	mv	a0,a5
  a6:	00000097          	auipc	ra,0x0
  aa:	642080e7          	jalr	1602(ra) # 6e8 <settickets>
        printf("Child 1 started\n");
  ae:	00001517          	auipc	a0,0x1
  b2:	b2a50513          	addi	a0,a0,-1238 # bd8 <malloc+0x152>
  b6:	00001097          	auipc	ra,0x1
  ba:	912080e7          	jalr	-1774(ra) # 9c8 <printf>
        sleep(1);
  be:	4505                	li	a0,1
  c0:	00000097          	auipc	ra,0x0
  c4:	5f8080e7          	jalr	1528(ra) # 6b8 <sleep>
        usless_work();
  c8:	00000097          	auipc	ra,0x0
  cc:	f38080e7          	jalr	-200(ra) # 0 <usless_work>
        printf("Child 1 exited\n");
  d0:	00001517          	auipc	a0,0x1
  d4:	b2050513          	addi	a0,a0,-1248 # bf0 <malloc+0x16a>
  d8:	00001097          	auipc	ra,0x1
  dc:	8f0080e7          	jalr	-1808(ra) # 9c8 <printf>
        exit(0);
  e0:	4501                	li	a0,0
  e2:	00000097          	auipc	ra,0x0
  e6:	546080e7          	jalr	1350(ra) # 628 <exit>

    }
    if (fork() == 0) {
  ea:	00000097          	auipc	ra,0x0
  ee:	536080e7          	jalr	1334(ra) # 620 <fork>
  f2:	87aa                	mv	a5,a0
  f4:	e7b1                	bnez	a5,140 <test0+0x10a>
        settickets(prog2_tickets);
  f6:	fe842783          	lw	a5,-24(s0)
  fa:	853e                	mv	a0,a5
  fc:	00000097          	auipc	ra,0x0
 100:	5ec080e7          	jalr	1516(ra) # 6e8 <settickets>
        printf("Child 2 started\n");
 104:	00001517          	auipc	a0,0x1
 108:	afc50513          	addi	a0,a0,-1284 # c00 <malloc+0x17a>
 10c:	00001097          	auipc	ra,0x1
 110:	8bc080e7          	jalr	-1860(ra) # 9c8 <printf>
        sleep(1);
 114:	4505                	li	a0,1
 116:	00000097          	auipc	ra,0x0
 11a:	5a2080e7          	jalr	1442(ra) # 6b8 <sleep>
        usless_work();
 11e:	00000097          	auipc	ra,0x0
 122:	ee2080e7          	jalr	-286(ra) # 0 <usless_work>
        printf("Child 2 exited\n");
 126:	00001517          	auipc	a0,0x1
 12a:	af250513          	addi	a0,a0,-1294 # c18 <malloc+0x192>
 12e:	00001097          	auipc	ra,0x1
 132:	89a080e7          	jalr	-1894(ra) # 9c8 <printf>
        exit(0);
 136:	4501                	li	a0,0
 138:	00000097          	auipc	ra,0x0
 13c:	4f0080e7          	jalr	1264(ra) # 628 <exit>
    }
    if (fork() == 0) {
 140:	00000097          	auipc	ra,0x0
 144:	4e0080e7          	jalr	1248(ra) # 620 <fork>
 148:	87aa                	mv	a5,a0
 14a:	e7b1                	bnez	a5,196 <test0+0x160>
        settickets(prog3_tickets);
 14c:	fe442783          	lw	a5,-28(s0)
 150:	853e                	mv	a0,a5
 152:	00000097          	auipc	ra,0x0
 156:	596080e7          	jalr	1430(ra) # 6e8 <settickets>
        printf("Child 3 started\n");
 15a:	00001517          	auipc	a0,0x1
 15e:	ace50513          	addi	a0,a0,-1330 # c28 <malloc+0x1a2>
 162:	00001097          	auipc	ra,0x1
 166:	866080e7          	jalr	-1946(ra) # 9c8 <printf>
        sleep(1);
 16a:	4505                	li	a0,1
 16c:	00000097          	auipc	ra,0x0
 170:	54c080e7          	jalr	1356(ra) # 6b8 <sleep>
        usless_work();
 174:	00000097          	auipc	ra,0x0
 178:	e8c080e7          	jalr	-372(ra) # 0 <usless_work>
        printf("Child 3 exited\n");
 17c:	00001517          	auipc	a0,0x1
 180:	ac450513          	addi	a0,a0,-1340 # c40 <malloc+0x1ba>
 184:	00001097          	auipc	ra,0x1
 188:	844080e7          	jalr	-1980(ra) # 9c8 <printf>
        exit(0);
 18c:	4501                	li	a0,0
 18e:	00000097          	auipc	ra,0x0
 192:	49a080e7          	jalr	1178(ra) # 628 <exit>
    }
    if (fork() == 0) {
 196:	00000097          	auipc	ra,0x0
 19a:	48a080e7          	jalr	1162(ra) # 620 <fork>
 19e:	87aa                	mv	a5,a0
 1a0:	e7b1                	bnez	a5,1ec <test0+0x1b6>
        settickets(prog4_tickets);
 1a2:	fe042783          	lw	a5,-32(s0)
 1a6:	853e                	mv	a0,a5
 1a8:	00000097          	auipc	ra,0x0
 1ac:	540080e7          	jalr	1344(ra) # 6e8 <settickets>
        printf("Child 4 started\n");
 1b0:	00001517          	auipc	a0,0x1
 1b4:	aa050513          	addi	a0,a0,-1376 # c50 <malloc+0x1ca>
 1b8:	00001097          	auipc	ra,0x1
 1bc:	810080e7          	jalr	-2032(ra) # 9c8 <printf>
        sleep(1);
 1c0:	4505                	li	a0,1
 1c2:	00000097          	auipc	ra,0x0
 1c6:	4f6080e7          	jalr	1270(ra) # 6b8 <sleep>
        usless_work();
 1ca:	00000097          	auipc	ra,0x0
 1ce:	e36080e7          	jalr	-458(ra) # 0 <usless_work>
        printf("Child 4 exited\n");
 1d2:	00001517          	auipc	a0,0x1
 1d6:	a9650513          	addi	a0,a0,-1386 # c68 <malloc+0x1e2>
 1da:	00000097          	auipc	ra,0x0
 1de:	7ee080e7          	jalr	2030(ra) # 9c8 <printf>
        exit(0);
 1e2:	4501                	li	a0,0
 1e4:	00000097          	auipc	ra,0x0
 1e8:	444080e7          	jalr	1092(ra) # 628 <exit>
    }
    wait(0);
 1ec:	4501                	li	a0,0
 1ee:	00000097          	auipc	ra,0x0
 1f2:	442080e7          	jalr	1090(ra) # 630 <wait>
    wait(0);
 1f6:	4501                	li	a0,0
 1f8:	00000097          	auipc	ra,0x0
 1fc:	438080e7          	jalr	1080(ra) # 630 <wait>
    wait(0);
 200:	4501                	li	a0,0
 202:	00000097          	auipc	ra,0x0
 206:	42e080e7          	jalr	1070(ra) # 630 <wait>
    wait(0);
 20a:	4501                	li	a0,0
 20c:	00000097          	auipc	ra,0x0
 210:	424080e7          	jalr	1060(ra) # 630 <wait>
    printf("The correct order should be ideally 3,4,2,1.\n");
 214:	00001517          	auipc	a0,0x1
 218:	a6450513          	addi	a0,a0,-1436 # c78 <malloc+0x1f2>
 21c:	00000097          	auipc	ra,0x0
 220:	7ac080e7          	jalr	1964(ra) # 9c8 <printf>

}
 224:	0001                	nop
 226:	60e2                	ld	ra,24(sp)
 228:	6442                	ld	s0,16(sp)
 22a:	6105                	addi	sp,sp,32
 22c:	8082                	ret

000000000000022e <test1>:

void test1(){
 22e:	1101                	addi	sp,sp,-32
 230:	ec06                	sd	ra,24(sp)
 232:	e822                	sd	s0,16(sp)
 234:	1000                	addi	s0,sp,32
    printf("TEST1\n"); // To check the FCFS part of the implementation
 236:	00001517          	auipc	a0,0x1
 23a:	a7250513          	addi	a0,a0,-1422 # ca8 <malloc+0x222>
 23e:	00000097          	auipc	ra,0x0
 242:	78a080e7          	jalr	1930(ra) # 9c8 <printf>
    int tickets = 30; // To check for this finish times
 246:	47f9                	li	a5,30
 248:	fef42623          	sw	a5,-20(s0)
    settickets(30); // So that now, the parent will always get the main priority to set up its children
 24c:	4579                	li	a0,30
 24e:	00000097          	auipc	ra,0x0
 252:	49a080e7          	jalr	1178(ra) # 6e8 <settickets>
    sleep(1); // So that this will have a different ctime than others. Ctime is not entirely very accurate
 256:	4505                	li	a0,1
 258:	00000097          	auipc	ra,0x0
 25c:	460080e7          	jalr	1120(ra) # 6b8 <sleep>

    printf("Child 1 started\n");
 260:	00001517          	auipc	a0,0x1
 264:	97850513          	addi	a0,a0,-1672 # bd8 <malloc+0x152>
 268:	00000097          	auipc	ra,0x0
 26c:	760080e7          	jalr	1888(ra) # 9c8 <printf>
    if (fork() == 0) {
 270:	00000097          	auipc	ra,0x0
 274:	3b0080e7          	jalr	944(ra) # 620 <fork>
 278:	87aa                	mv	a5,a0
 27a:	eb8d                	bnez	a5,2ac <test1+0x7e>
        settickets(tickets);
 27c:	fec42783          	lw	a5,-20(s0)
 280:	853e                	mv	a0,a5
 282:	00000097          	auipc	ra,0x0
 286:	466080e7          	jalr	1126(ra) # 6e8 <settickets>
        usless_work();
 28a:	00000097          	auipc	ra,0x0
 28e:	d76080e7          	jalr	-650(ra) # 0 <usless_work>
        printf("Child 1 ended\n");
 292:	00001517          	auipc	a0,0x1
 296:	a1e50513          	addi	a0,a0,-1506 # cb0 <malloc+0x22a>
 29a:	00000097          	auipc	ra,0x0
 29e:	72e080e7          	jalr	1838(ra) # 9c8 <printf>
        exit(0);
 2a2:	4501                	li	a0,0
 2a4:	00000097          	auipc	ra,0x0
 2a8:	384080e7          	jalr	900(ra) # 628 <exit>
    }
    printf("Child 2 started\n");
 2ac:	00001517          	auipc	a0,0x1
 2b0:	95450513          	addi	a0,a0,-1708 # c00 <malloc+0x17a>
 2b4:	00000097          	auipc	ra,0x0
 2b8:	714080e7          	jalr	1812(ra) # 9c8 <printf>
    if (fork() == 0) {
 2bc:	00000097          	auipc	ra,0x0
 2c0:	364080e7          	jalr	868(ra) # 620 <fork>
 2c4:	87aa                	mv	a5,a0
 2c6:	eb8d                	bnez	a5,2f8 <test1+0xca>
        settickets(tickets);
 2c8:	fec42783          	lw	a5,-20(s0)
 2cc:	853e                	mv	a0,a5
 2ce:	00000097          	auipc	ra,0x0
 2d2:	41a080e7          	jalr	1050(ra) # 6e8 <settickets>
        usless_work();
 2d6:	00000097          	auipc	ra,0x0
 2da:	d2a080e7          	jalr	-726(ra) # 0 <usless_work>
        printf("Child 2 ended\n");
 2de:	00001517          	auipc	a0,0x1
 2e2:	9e250513          	addi	a0,a0,-1566 # cc0 <malloc+0x23a>
 2e6:	00000097          	auipc	ra,0x0
 2ea:	6e2080e7          	jalr	1762(ra) # 9c8 <printf>
        exit(0);
 2ee:	4501                	li	a0,0
 2f0:	00000097          	auipc	ra,0x0
 2f4:	338080e7          	jalr	824(ra) # 628 <exit>
    }
    printf("Child 3 started\n");
 2f8:	00001517          	auipc	a0,0x1
 2fc:	93050513          	addi	a0,a0,-1744 # c28 <malloc+0x1a2>
 300:	00000097          	auipc	ra,0x0
 304:	6c8080e7          	jalr	1736(ra) # 9c8 <printf>
    if (fork() == 0) {
 308:	00000097          	auipc	ra,0x0
 30c:	318080e7          	jalr	792(ra) # 620 <fork>
 310:	87aa                	mv	a5,a0
 312:	eb8d                	bnez	a5,344 <test1+0x116>
        settickets(tickets);
 314:	fec42783          	lw	a5,-20(s0)
 318:	853e                	mv	a0,a5
 31a:	00000097          	auipc	ra,0x0
 31e:	3ce080e7          	jalr	974(ra) # 6e8 <settickets>
        usless_work();
 322:	00000097          	auipc	ra,0x0
 326:	cde080e7          	jalr	-802(ra) # 0 <usless_work>
        printf("Child 3 ended\n");
 32a:	00001517          	auipc	a0,0x1
 32e:	9a650513          	addi	a0,a0,-1626 # cd0 <malloc+0x24a>
 332:	00000097          	auipc	ra,0x0
 336:	696080e7          	jalr	1686(ra) # 9c8 <printf>
        exit(0);
 33a:	4501                	li	a0,0
 33c:	00000097          	auipc	ra,0x0
 340:	2ec080e7          	jalr	748(ra) # 628 <exit>
    }
    wait(0);
 344:	4501                	li	a0,0
 346:	00000097          	auipc	ra,0x0
 34a:	2ea080e7          	jalr	746(ra) # 630 <wait>
    wait(0);
 34e:	4501                	li	a0,0
 350:	00000097          	auipc	ra,0x0
 354:	2e0080e7          	jalr	736(ra) # 630 <wait>
    wait(0);
 358:	4501                	li	a0,0
 35a:	00000097          	auipc	ra,0x0
 35e:	2d6080e7          	jalr	726(ra) # 630 <wait>
    // printf("The order should be 4,3 and 2 then 1 since all tickets have same value\n");
}
 362:	0001                	nop
 364:	60e2                	ld	ra,24(sp)
 366:	6442                	ld	s0,16(sp)
 368:	6105                	addi	sp,sp,32
 36a:	8082                	ret

000000000000036c <main>:
int main() {
 36c:	1141                	addi	sp,sp,-16
 36e:	e406                	sd	ra,8(sp)
 370:	e022                	sd	s0,0(sp)
 372:	0800                	addi	s0,sp,16
    test0();
 374:	00000097          	auipc	ra,0x0
 378:	cc2080e7          	jalr	-830(ra) # 36 <test0>
    test1();
 37c:	00000097          	auipc	ra,0x0
 380:	eb2080e7          	jalr	-334(ra) # 22e <test1>
    printf("Finished all tests\n");
 384:	00001517          	auipc	a0,0x1
 388:	95c50513          	addi	a0,a0,-1700 # ce0 <malloc+0x25a>
 38c:	00000097          	auipc	ra,0x0
 390:	63c080e7          	jalr	1596(ra) # 9c8 <printf>

    return 0;
 394:	4781                	li	a5,0
}
 396:	853e                	mv	a0,a5
 398:	60a2                	ld	ra,8(sp)
 39a:	6402                	ld	s0,0(sp)
 39c:	0141                	addi	sp,sp,16
 39e:	8082                	ret

00000000000003a0 <_main>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
_main()
{
 3a0:	1141                	addi	sp,sp,-16
 3a2:	e406                	sd	ra,8(sp)
 3a4:	e022                	sd	s0,0(sp)
 3a6:	0800                	addi	s0,sp,16
  extern int main();
  main();
 3a8:	00000097          	auipc	ra,0x0
 3ac:	fc4080e7          	jalr	-60(ra) # 36c <main>
  exit(0);
 3b0:	4501                	li	a0,0
 3b2:	00000097          	auipc	ra,0x0
 3b6:	276080e7          	jalr	630(ra) # 628 <exit>

00000000000003ba <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 3ba:	1141                	addi	sp,sp,-16
 3bc:	e422                	sd	s0,8(sp)
 3be:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 3c0:	87aa                	mv	a5,a0
 3c2:	0585                	addi	a1,a1,1
 3c4:	0785                	addi	a5,a5,1
 3c6:	fff5c703          	lbu	a4,-1(a1)
 3ca:	fee78fa3          	sb	a4,-1(a5)
 3ce:	fb75                	bnez	a4,3c2 <strcpy+0x8>
    ;
  return os;
}
 3d0:	6422                	ld	s0,8(sp)
 3d2:	0141                	addi	sp,sp,16
 3d4:	8082                	ret

00000000000003d6 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 3d6:	1141                	addi	sp,sp,-16
 3d8:	e422                	sd	s0,8(sp)
 3da:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 3dc:	00054783          	lbu	a5,0(a0)
 3e0:	cb91                	beqz	a5,3f4 <strcmp+0x1e>
 3e2:	0005c703          	lbu	a4,0(a1)
 3e6:	00f71763          	bne	a4,a5,3f4 <strcmp+0x1e>
    p++, q++;
 3ea:	0505                	addi	a0,a0,1
 3ec:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 3ee:	00054783          	lbu	a5,0(a0)
 3f2:	fbe5                	bnez	a5,3e2 <strcmp+0xc>
  return (uchar)*p - (uchar)*q;
 3f4:	0005c503          	lbu	a0,0(a1)
}
 3f8:	40a7853b          	subw	a0,a5,a0
 3fc:	6422                	ld	s0,8(sp)
 3fe:	0141                	addi	sp,sp,16
 400:	8082                	ret

0000000000000402 <strlen>:

uint
strlen(const char *s)
{
 402:	1141                	addi	sp,sp,-16
 404:	e422                	sd	s0,8(sp)
 406:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 408:	00054783          	lbu	a5,0(a0)
 40c:	cf91                	beqz	a5,428 <strlen+0x26>
 40e:	0505                	addi	a0,a0,1
 410:	87aa                	mv	a5,a0
 412:	4685                	li	a3,1
 414:	9e89                	subw	a3,a3,a0
 416:	00f6853b          	addw	a0,a3,a5
 41a:	0785                	addi	a5,a5,1
 41c:	fff7c703          	lbu	a4,-1(a5)
 420:	fb7d                	bnez	a4,416 <strlen+0x14>
    ;
  return n;
}
 422:	6422                	ld	s0,8(sp)
 424:	0141                	addi	sp,sp,16
 426:	8082                	ret
  for(n = 0; s[n]; n++)
 428:	4501                	li	a0,0
 42a:	bfe5                	j	422 <strlen+0x20>

000000000000042c <memset>:

void*
memset(void *dst, int c, uint n)
{
 42c:	1141                	addi	sp,sp,-16
 42e:	e422                	sd	s0,8(sp)
 430:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 432:	ca19                	beqz	a2,448 <memset+0x1c>
 434:	87aa                	mv	a5,a0
 436:	1602                	slli	a2,a2,0x20
 438:	9201                	srli	a2,a2,0x20
 43a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 43e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 442:	0785                	addi	a5,a5,1
 444:	fee79de3          	bne	a5,a4,43e <memset+0x12>
  }
  return dst;
}
 448:	6422                	ld	s0,8(sp)
 44a:	0141                	addi	sp,sp,16
 44c:	8082                	ret

000000000000044e <strchr>:

char*
strchr(const char *s, char c)
{
 44e:	1141                	addi	sp,sp,-16
 450:	e422                	sd	s0,8(sp)
 452:	0800                	addi	s0,sp,16
  for(; *s; s++)
 454:	00054783          	lbu	a5,0(a0)
 458:	cb99                	beqz	a5,46e <strchr+0x20>
    if(*s == c)
 45a:	00f58763          	beq	a1,a5,468 <strchr+0x1a>
  for(; *s; s++)
 45e:	0505                	addi	a0,a0,1
 460:	00054783          	lbu	a5,0(a0)
 464:	fbfd                	bnez	a5,45a <strchr+0xc>
      return (char*)s;
  return 0;
 466:	4501                	li	a0,0
}
 468:	6422                	ld	s0,8(sp)
 46a:	0141                	addi	sp,sp,16
 46c:	8082                	ret
  return 0;
 46e:	4501                	li	a0,0
 470:	bfe5                	j	468 <strchr+0x1a>

0000000000000472 <gets>:

char*
gets(char *buf, int max)
{
 472:	711d                	addi	sp,sp,-96
 474:	ec86                	sd	ra,88(sp)
 476:	e8a2                	sd	s0,80(sp)
 478:	e4a6                	sd	s1,72(sp)
 47a:	e0ca                	sd	s2,64(sp)
 47c:	fc4e                	sd	s3,56(sp)
 47e:	f852                	sd	s4,48(sp)
 480:	f456                	sd	s5,40(sp)
 482:	f05a                	sd	s6,32(sp)
 484:	ec5e                	sd	s7,24(sp)
 486:	1080                	addi	s0,sp,96
 488:	8baa                	mv	s7,a0
 48a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 48c:	892a                	mv	s2,a0
 48e:	4481                	li	s1,0
    cc = read(0, &c, 1);
    if(cc < 1)
      break;
    buf[i++] = c;
    if(c == '\n' || c == '\r')
 490:	4aa9                	li	s5,10
 492:	4b35                	li	s6,13
  for(i=0; i+1 < max; ){
 494:	89a6                	mv	s3,s1
 496:	2485                	addiw	s1,s1,1
 498:	0344d863          	bge	s1,s4,4c8 <gets+0x56>
    cc = read(0, &c, 1);
 49c:	4605                	li	a2,1
 49e:	faf40593          	addi	a1,s0,-81
 4a2:	4501                	li	a0,0
 4a4:	00000097          	auipc	ra,0x0
 4a8:	19c080e7          	jalr	412(ra) # 640 <read>
    if(cc < 1)
 4ac:	00a05e63          	blez	a0,4c8 <gets+0x56>
    buf[i++] = c;
 4b0:	faf44783          	lbu	a5,-81(s0)
 4b4:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 4b8:	01578763          	beq	a5,s5,4c6 <gets+0x54>
 4bc:	0905                	addi	s2,s2,1
 4be:	fd679be3          	bne	a5,s6,494 <gets+0x22>
  for(i=0; i+1 < max; ){
 4c2:	89a6                	mv	s3,s1
 4c4:	a011                	j	4c8 <gets+0x56>
 4c6:	89a6                	mv	s3,s1
      break;
  }
  buf[i] = '\0';
 4c8:	99de                	add	s3,s3,s7
 4ca:	00098023          	sb	zero,0(s3)
  return buf;
}
 4ce:	855e                	mv	a0,s7
 4d0:	60e6                	ld	ra,88(sp)
 4d2:	6446                	ld	s0,80(sp)
 4d4:	64a6                	ld	s1,72(sp)
 4d6:	6906                	ld	s2,64(sp)
 4d8:	79e2                	ld	s3,56(sp)
 4da:	7a42                	ld	s4,48(sp)
 4dc:	7aa2                	ld	s5,40(sp)
 4de:	7b02                	ld	s6,32(sp)
 4e0:	6be2                	ld	s7,24(sp)
 4e2:	6125                	addi	sp,sp,96
 4e4:	8082                	ret

00000000000004e6 <stat>:

int
stat(const char *n, struct stat *st)
{
 4e6:	1101                	addi	sp,sp,-32
 4e8:	ec06                	sd	ra,24(sp)
 4ea:	e822                	sd	s0,16(sp)
 4ec:	e426                	sd	s1,8(sp)
 4ee:	e04a                	sd	s2,0(sp)
 4f0:	1000                	addi	s0,sp,32
 4f2:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4f4:	4581                	li	a1,0
 4f6:	00000097          	auipc	ra,0x0
 4fa:	172080e7          	jalr	370(ra) # 668 <open>
  if(fd < 0)
 4fe:	02054563          	bltz	a0,528 <stat+0x42>
 502:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 504:	85ca                	mv	a1,s2
 506:	00000097          	auipc	ra,0x0
 50a:	17a080e7          	jalr	378(ra) # 680 <fstat>
 50e:	892a                	mv	s2,a0
  close(fd);
 510:	8526                	mv	a0,s1
 512:	00000097          	auipc	ra,0x0
 516:	13e080e7          	jalr	318(ra) # 650 <close>
  return r;
}
 51a:	854a                	mv	a0,s2
 51c:	60e2                	ld	ra,24(sp)
 51e:	6442                	ld	s0,16(sp)
 520:	64a2                	ld	s1,8(sp)
 522:	6902                	ld	s2,0(sp)
 524:	6105                	addi	sp,sp,32
 526:	8082                	ret
    return -1;
 528:	597d                	li	s2,-1
 52a:	bfc5                	j	51a <stat+0x34>

000000000000052c <atoi>:

int
atoi(const char *s)
{
 52c:	1141                	addi	sp,sp,-16
 52e:	e422                	sd	s0,8(sp)
 530:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 532:	00054603          	lbu	a2,0(a0)
 536:	fd06079b          	addiw	a5,a2,-48
 53a:	0ff7f793          	andi	a5,a5,255
 53e:	4725                	li	a4,9
 540:	02f76963          	bltu	a4,a5,572 <atoi+0x46>
 544:	86aa                	mv	a3,a0
  n = 0;
 546:	4501                	li	a0,0
  while('0' <= *s && *s <= '9')
 548:	45a5                	li	a1,9
    n = n*10 + *s++ - '0';
 54a:	0685                	addi	a3,a3,1
 54c:	0025179b          	slliw	a5,a0,0x2
 550:	9fa9                	addw	a5,a5,a0
 552:	0017979b          	slliw	a5,a5,0x1
 556:	9fb1                	addw	a5,a5,a2
 558:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 55c:	0006c603          	lbu	a2,0(a3)
 560:	fd06071b          	addiw	a4,a2,-48
 564:	0ff77713          	andi	a4,a4,255
 568:	fee5f1e3          	bgeu	a1,a4,54a <atoi+0x1e>
  return n;
}
 56c:	6422                	ld	s0,8(sp)
 56e:	0141                	addi	sp,sp,16
 570:	8082                	ret
  n = 0;
 572:	4501                	li	a0,0
 574:	bfe5                	j	56c <atoi+0x40>

0000000000000576 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 576:	1141                	addi	sp,sp,-16
 578:	e422                	sd	s0,8(sp)
 57a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 57c:	02b57463          	bgeu	a0,a1,5a4 <memmove+0x2e>
    while(n-- > 0)
 580:	00c05f63          	blez	a2,59e <memmove+0x28>
 584:	1602                	slli	a2,a2,0x20
 586:	9201                	srli	a2,a2,0x20
 588:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 58c:	872a                	mv	a4,a0
      *dst++ = *src++;
 58e:	0585                	addi	a1,a1,1
 590:	0705                	addi	a4,a4,1
 592:	fff5c683          	lbu	a3,-1(a1)
 596:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 59a:	fee79ae3          	bne	a5,a4,58e <memmove+0x18>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 59e:	6422                	ld	s0,8(sp)
 5a0:	0141                	addi	sp,sp,16
 5a2:	8082                	ret
    dst += n;
 5a4:	00c50733          	add	a4,a0,a2
    src += n;
 5a8:	95b2                	add	a1,a1,a2
    while(n-- > 0)
 5aa:	fec05ae3          	blez	a2,59e <memmove+0x28>
 5ae:	fff6079b          	addiw	a5,a2,-1
 5b2:	1782                	slli	a5,a5,0x20
 5b4:	9381                	srli	a5,a5,0x20
 5b6:	fff7c793          	not	a5,a5
 5ba:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 5bc:	15fd                	addi	a1,a1,-1
 5be:	177d                	addi	a4,a4,-1
 5c0:	0005c683          	lbu	a3,0(a1)
 5c4:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 5c8:	fee79ae3          	bne	a5,a4,5bc <memmove+0x46>
 5cc:	bfc9                	j	59e <memmove+0x28>

00000000000005ce <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 5ce:	1141                	addi	sp,sp,-16
 5d0:	e422                	sd	s0,8(sp)
 5d2:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 5d4:	ca05                	beqz	a2,604 <memcmp+0x36>
 5d6:	fff6069b          	addiw	a3,a2,-1
 5da:	1682                	slli	a3,a3,0x20
 5dc:	9281                	srli	a3,a3,0x20
 5de:	0685                	addi	a3,a3,1
 5e0:	96aa                	add	a3,a3,a0
    if (*p1 != *p2) {
 5e2:	00054783          	lbu	a5,0(a0)
 5e6:	0005c703          	lbu	a4,0(a1)
 5ea:	00e79863          	bne	a5,a4,5fa <memcmp+0x2c>
      return *p1 - *p2;
    }
    p1++;
 5ee:	0505                	addi	a0,a0,1
    p2++;
 5f0:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 5f2:	fed518e3          	bne	a0,a3,5e2 <memcmp+0x14>
  }
  return 0;
 5f6:	4501                	li	a0,0
 5f8:	a019                	j	5fe <memcmp+0x30>
      return *p1 - *p2;
 5fa:	40e7853b          	subw	a0,a5,a4
}
 5fe:	6422                	ld	s0,8(sp)
 600:	0141                	addi	sp,sp,16
 602:	8082                	ret
  return 0;
 604:	4501                	li	a0,0
 606:	bfe5                	j	5fe <memcmp+0x30>

0000000000000608 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 608:	1141                	addi	sp,sp,-16
 60a:	e406                	sd	ra,8(sp)
 60c:	e022                	sd	s0,0(sp)
 60e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 610:	00000097          	auipc	ra,0x0
 614:	f66080e7          	jalr	-154(ra) # 576 <memmove>
}
 618:	60a2                	ld	ra,8(sp)
 61a:	6402                	ld	s0,0(sp)
 61c:	0141                	addi	sp,sp,16
 61e:	8082                	ret

0000000000000620 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 620:	4885                	li	a7,1
 ecall
 622:	00000073          	ecall
 ret
 626:	8082                	ret

0000000000000628 <exit>:
.global exit
exit:
 li a7, SYS_exit
 628:	4889                	li	a7,2
 ecall
 62a:	00000073          	ecall
 ret
 62e:	8082                	ret

0000000000000630 <wait>:
.global wait
wait:
 li a7, SYS_wait
 630:	488d                	li	a7,3
 ecall
 632:	00000073          	ecall
 ret
 636:	8082                	ret

0000000000000638 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 638:	4891                	li	a7,4
 ecall
 63a:	00000073          	ecall
 ret
 63e:	8082                	ret

0000000000000640 <read>:
.global read
read:
 li a7, SYS_read
 640:	4895                	li	a7,5
 ecall
 642:	00000073          	ecall
 ret
 646:	8082                	ret

0000000000000648 <write>:
.global write
write:
 li a7, SYS_write
 648:	48c1                	li	a7,16
 ecall
 64a:	00000073          	ecall
 ret
 64e:	8082                	ret

0000000000000650 <close>:
.global close
close:
 li a7, SYS_close
 650:	48d5                	li	a7,21
 ecall
 652:	00000073          	ecall
 ret
 656:	8082                	ret

0000000000000658 <kill>:
.global kill
kill:
 li a7, SYS_kill
 658:	4899                	li	a7,6
 ecall
 65a:	00000073          	ecall
 ret
 65e:	8082                	ret

0000000000000660 <exec>:
.global exec
exec:
 li a7, SYS_exec
 660:	489d                	li	a7,7
 ecall
 662:	00000073          	ecall
 ret
 666:	8082                	ret

0000000000000668 <open>:
.global open
open:
 li a7, SYS_open
 668:	48bd                	li	a7,15
 ecall
 66a:	00000073          	ecall
 ret
 66e:	8082                	ret

0000000000000670 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 670:	48c5                	li	a7,17
 ecall
 672:	00000073          	ecall
 ret
 676:	8082                	ret

0000000000000678 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 678:	48c9                	li	a7,18
 ecall
 67a:	00000073          	ecall
 ret
 67e:	8082                	ret

0000000000000680 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 680:	48a1                	li	a7,8
 ecall
 682:	00000073          	ecall
 ret
 686:	8082                	ret

0000000000000688 <link>:
.global link
link:
 li a7, SYS_link
 688:	48cd                	li	a7,19
 ecall
 68a:	00000073          	ecall
 ret
 68e:	8082                	ret

0000000000000690 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 690:	48d1                	li	a7,20
 ecall
 692:	00000073          	ecall
 ret
 696:	8082                	ret

0000000000000698 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 698:	48a5                	li	a7,9
 ecall
 69a:	00000073          	ecall
 ret
 69e:	8082                	ret

00000000000006a0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 6a0:	48a9                	li	a7,10
 ecall
 6a2:	00000073          	ecall
 ret
 6a6:	8082                	ret

00000000000006a8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 6a8:	48ad                	li	a7,11
 ecall
 6aa:	00000073          	ecall
 ret
 6ae:	8082                	ret

00000000000006b0 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 6b0:	48b1                	li	a7,12
 ecall
 6b2:	00000073          	ecall
 ret
 6b6:	8082                	ret

00000000000006b8 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 6b8:	48b5                	li	a7,13
 ecall
 6ba:	00000073          	ecall
 ret
 6be:	8082                	ret

00000000000006c0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 6c0:	48b9                	li	a7,14
 ecall
 6c2:	00000073          	ecall
 ret
 6c6:	8082                	ret

00000000000006c8 <waitx>:
.global waitx
waitx:
 li a7, SYS_waitx
 6c8:	48d9                	li	a7,22
 ecall
 6ca:	00000073          	ecall
 ret
 6ce:	8082                	ret

00000000000006d0 <getSysCount>:
.global getSysCount
getSysCount:
 li a7, SYS_getSysCount
 6d0:	48dd                	li	a7,23
 ecall
 6d2:	00000073          	ecall
 ret
 6d6:	8082                	ret

00000000000006d8 <sigalarm>:
.global sigalarm
sigalarm:
 li a7, SYS_sigalarm
 6d8:	48e1                	li	a7,24
 ecall
 6da:	00000073          	ecall
 ret
 6de:	8082                	ret

00000000000006e0 <sigreturn>:
.global sigreturn
sigreturn:
 li a7, SYS_sigreturn
 6e0:	48e5                	li	a7,25
 ecall
 6e2:	00000073          	ecall
 ret
 6e6:	8082                	ret

00000000000006e8 <settickets>:
.global settickets
settickets:
 li a7, SYS_settickets
 6e8:	48e9                	li	a7,26
 ecall
 6ea:	00000073          	ecall
 ret
 6ee:	8082                	ret

00000000000006f0 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6f0:	1101                	addi	sp,sp,-32
 6f2:	ec06                	sd	ra,24(sp)
 6f4:	e822                	sd	s0,16(sp)
 6f6:	1000                	addi	s0,sp,32
 6f8:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 6fc:	4605                	li	a2,1
 6fe:	fef40593          	addi	a1,s0,-17
 702:	00000097          	auipc	ra,0x0
 706:	f46080e7          	jalr	-186(ra) # 648 <write>
}
 70a:	60e2                	ld	ra,24(sp)
 70c:	6442                	ld	s0,16(sp)
 70e:	6105                	addi	sp,sp,32
 710:	8082                	ret

0000000000000712 <printint>:

static void
printint(int fd, int xx, int base, int sgn)
{
 712:	7139                	addi	sp,sp,-64
 714:	fc06                	sd	ra,56(sp)
 716:	f822                	sd	s0,48(sp)
 718:	f426                	sd	s1,40(sp)
 71a:	f04a                	sd	s2,32(sp)
 71c:	ec4e                	sd	s3,24(sp)
 71e:	0080                	addi	s0,sp,64
 720:	84aa                	mv	s1,a0
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 722:	c299                	beqz	a3,728 <printint+0x16>
 724:	0805c863          	bltz	a1,7b4 <printint+0xa2>
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 728:	2581                	sext.w	a1,a1
  neg = 0;
 72a:	4881                	li	a7,0
 72c:	fc040693          	addi	a3,s0,-64
  }

  i = 0;
 730:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 732:	2601                	sext.w	a2,a2
 734:	00000517          	auipc	a0,0x0
 738:	5cc50513          	addi	a0,a0,1484 # d00 <digits>
 73c:	883a                	mv	a6,a4
 73e:	2705                	addiw	a4,a4,1
 740:	02c5f7bb          	remuw	a5,a1,a2
 744:	1782                	slli	a5,a5,0x20
 746:	9381                	srli	a5,a5,0x20
 748:	97aa                	add	a5,a5,a0
 74a:	0007c783          	lbu	a5,0(a5)
 74e:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 752:	0005879b          	sext.w	a5,a1
 756:	02c5d5bb          	divuw	a1,a1,a2
 75a:	0685                	addi	a3,a3,1
 75c:	fec7f0e3          	bgeu	a5,a2,73c <printint+0x2a>
  if(neg)
 760:	00088b63          	beqz	a7,776 <printint+0x64>
    buf[i++] = '-';
 764:	fd040793          	addi	a5,s0,-48
 768:	973e                	add	a4,a4,a5
 76a:	02d00793          	li	a5,45
 76e:	fef70823          	sb	a5,-16(a4)
 772:	0028071b          	addiw	a4,a6,2

  while(--i >= 0)
 776:	02e05863          	blez	a4,7a6 <printint+0x94>
 77a:	fc040793          	addi	a5,s0,-64
 77e:	00e78933          	add	s2,a5,a4
 782:	fff78993          	addi	s3,a5,-1
 786:	99ba                	add	s3,s3,a4
 788:	377d                	addiw	a4,a4,-1
 78a:	1702                	slli	a4,a4,0x20
 78c:	9301                	srli	a4,a4,0x20
 78e:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 792:	fff94583          	lbu	a1,-1(s2)
 796:	8526                	mv	a0,s1
 798:	00000097          	auipc	ra,0x0
 79c:	f58080e7          	jalr	-168(ra) # 6f0 <putc>
  while(--i >= 0)
 7a0:	197d                	addi	s2,s2,-1
 7a2:	ff3918e3          	bne	s2,s3,792 <printint+0x80>
}
 7a6:	70e2                	ld	ra,56(sp)
 7a8:	7442                	ld	s0,48(sp)
 7aa:	74a2                	ld	s1,40(sp)
 7ac:	7902                	ld	s2,32(sp)
 7ae:	69e2                	ld	s3,24(sp)
 7b0:	6121                	addi	sp,sp,64
 7b2:	8082                	ret
    x = -xx;
 7b4:	40b005bb          	negw	a1,a1
    neg = 1;
 7b8:	4885                	li	a7,1
    x = -xx;
 7ba:	bf8d                	j	72c <printint+0x1a>

00000000000007bc <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 7bc:	7119                	addi	sp,sp,-128
 7be:	fc86                	sd	ra,120(sp)
 7c0:	f8a2                	sd	s0,112(sp)
 7c2:	f4a6                	sd	s1,104(sp)
 7c4:	f0ca                	sd	s2,96(sp)
 7c6:	ecce                	sd	s3,88(sp)
 7c8:	e8d2                	sd	s4,80(sp)
 7ca:	e4d6                	sd	s5,72(sp)
 7cc:	e0da                	sd	s6,64(sp)
 7ce:	fc5e                	sd	s7,56(sp)
 7d0:	f862                	sd	s8,48(sp)
 7d2:	f466                	sd	s9,40(sp)
 7d4:	f06a                	sd	s10,32(sp)
 7d6:	ec6e                	sd	s11,24(sp)
 7d8:	0100                	addi	s0,sp,128
  char *s;
  int c, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 7da:	0005c903          	lbu	s2,0(a1)
 7de:	18090f63          	beqz	s2,97c <vprintf+0x1c0>
 7e2:	8aaa                	mv	s5,a0
 7e4:	8b32                	mv	s6,a2
 7e6:	00158493          	addi	s1,a1,1
  state = 0;
 7ea:	4981                	li	s3,0
      if(c == '%'){
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
 7ec:	02500a13          	li	s4,37
      if(c == 'd'){
 7f0:	06400c13          	li	s8,100
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c == 'l') {
 7f4:	06c00c93          	li	s9,108
        printint(fd, va_arg(ap, uint64), 10, 0);
      } else if(c == 'x') {
 7f8:	07800d13          	li	s10,120
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c == 'p') {
 7fc:	07000d93          	li	s11,112
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 800:	00000b97          	auipc	s7,0x0
 804:	500b8b93          	addi	s7,s7,1280 # d00 <digits>
 808:	a839                	j	826 <vprintf+0x6a>
        putc(fd, c);
 80a:	85ca                	mv	a1,s2
 80c:	8556                	mv	a0,s5
 80e:	00000097          	auipc	ra,0x0
 812:	ee2080e7          	jalr	-286(ra) # 6f0 <putc>
 816:	a019                	j	81c <vprintf+0x60>
    } else if(state == '%'){
 818:	01498f63          	beq	s3,s4,836 <vprintf+0x7a>
  for(i = 0; fmt[i]; i++){
 81c:	0485                	addi	s1,s1,1
 81e:	fff4c903          	lbu	s2,-1(s1)
 822:	14090d63          	beqz	s2,97c <vprintf+0x1c0>
    c = fmt[i] & 0xff;
 826:	0009079b          	sext.w	a5,s2
    if(state == 0){
 82a:	fe0997e3          	bnez	s3,818 <vprintf+0x5c>
      if(c == '%'){
 82e:	fd479ee3          	bne	a5,s4,80a <vprintf+0x4e>
        state = '%';
 832:	89be                	mv	s3,a5
 834:	b7e5                	j	81c <vprintf+0x60>
      if(c == 'd'){
 836:	05878063          	beq	a5,s8,876 <vprintf+0xba>
      } else if(c == 'l') {
 83a:	05978c63          	beq	a5,s9,892 <vprintf+0xd6>
      } else if(c == 'x') {
 83e:	07a78863          	beq	a5,s10,8ae <vprintf+0xf2>
      } else if(c == 'p') {
 842:	09b78463          	beq	a5,s11,8ca <vprintf+0x10e>
        printptr(fd, va_arg(ap, uint64));
      } else if(c == 's'){
 846:	07300713          	li	a4,115
 84a:	0ce78663          	beq	a5,a4,916 <vprintf+0x15a>
          s = "(null)";
        while(*s != 0){
          putc(fd, *s);
          s++;
        }
      } else if(c == 'c'){
 84e:	06300713          	li	a4,99
 852:	0ee78e63          	beq	a5,a4,94e <vprintf+0x192>
        putc(fd, va_arg(ap, uint));
      } else if(c == '%'){
 856:	11478863          	beq	a5,s4,966 <vprintf+0x1aa>
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 85a:	85d2                	mv	a1,s4
 85c:	8556                	mv	a0,s5
 85e:	00000097          	auipc	ra,0x0
 862:	e92080e7          	jalr	-366(ra) # 6f0 <putc>
        putc(fd, c);
 866:	85ca                	mv	a1,s2
 868:	8556                	mv	a0,s5
 86a:	00000097          	auipc	ra,0x0
 86e:	e86080e7          	jalr	-378(ra) # 6f0 <putc>
      }
      state = 0;
 872:	4981                	li	s3,0
 874:	b765                	j	81c <vprintf+0x60>
        printint(fd, va_arg(ap, int), 10, 1);
 876:	008b0913          	addi	s2,s6,8
 87a:	4685                	li	a3,1
 87c:	4629                	li	a2,10
 87e:	000b2583          	lw	a1,0(s6)
 882:	8556                	mv	a0,s5
 884:	00000097          	auipc	ra,0x0
 888:	e8e080e7          	jalr	-370(ra) # 712 <printint>
 88c:	8b4a                	mv	s6,s2
      state = 0;
 88e:	4981                	li	s3,0
 890:	b771                	j	81c <vprintf+0x60>
        printint(fd, va_arg(ap, uint64), 10, 0);
 892:	008b0913          	addi	s2,s6,8
 896:	4681                	li	a3,0
 898:	4629                	li	a2,10
 89a:	000b2583          	lw	a1,0(s6)
 89e:	8556                	mv	a0,s5
 8a0:	00000097          	auipc	ra,0x0
 8a4:	e72080e7          	jalr	-398(ra) # 712 <printint>
 8a8:	8b4a                	mv	s6,s2
      state = 0;
 8aa:	4981                	li	s3,0
 8ac:	bf85                	j	81c <vprintf+0x60>
        printint(fd, va_arg(ap, int), 16, 0);
 8ae:	008b0913          	addi	s2,s6,8
 8b2:	4681                	li	a3,0
 8b4:	4641                	li	a2,16
 8b6:	000b2583          	lw	a1,0(s6)
 8ba:	8556                	mv	a0,s5
 8bc:	00000097          	auipc	ra,0x0
 8c0:	e56080e7          	jalr	-426(ra) # 712 <printint>
 8c4:	8b4a                	mv	s6,s2
      state = 0;
 8c6:	4981                	li	s3,0
 8c8:	bf91                	j	81c <vprintf+0x60>
        printptr(fd, va_arg(ap, uint64));
 8ca:	008b0793          	addi	a5,s6,8
 8ce:	f8f43423          	sd	a5,-120(s0)
 8d2:	000b3983          	ld	s3,0(s6)
  putc(fd, '0');
 8d6:	03000593          	li	a1,48
 8da:	8556                	mv	a0,s5
 8dc:	00000097          	auipc	ra,0x0
 8e0:	e14080e7          	jalr	-492(ra) # 6f0 <putc>
  putc(fd, 'x');
 8e4:	85ea                	mv	a1,s10
 8e6:	8556                	mv	a0,s5
 8e8:	00000097          	auipc	ra,0x0
 8ec:	e08080e7          	jalr	-504(ra) # 6f0 <putc>
 8f0:	4941                	li	s2,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8f2:	03c9d793          	srli	a5,s3,0x3c
 8f6:	97de                	add	a5,a5,s7
 8f8:	0007c583          	lbu	a1,0(a5)
 8fc:	8556                	mv	a0,s5
 8fe:	00000097          	auipc	ra,0x0
 902:	df2080e7          	jalr	-526(ra) # 6f0 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 906:	0992                	slli	s3,s3,0x4
 908:	397d                	addiw	s2,s2,-1
 90a:	fe0914e3          	bnez	s2,8f2 <vprintf+0x136>
        printptr(fd, va_arg(ap, uint64));
 90e:	f8843b03          	ld	s6,-120(s0)
      state = 0;
 912:	4981                	li	s3,0
 914:	b721                	j	81c <vprintf+0x60>
        s = va_arg(ap, char*);
 916:	008b0993          	addi	s3,s6,8
 91a:	000b3903          	ld	s2,0(s6)
        if(s == 0)
 91e:	02090163          	beqz	s2,940 <vprintf+0x184>
        while(*s != 0){
 922:	00094583          	lbu	a1,0(s2)
 926:	c9a1                	beqz	a1,976 <vprintf+0x1ba>
          putc(fd, *s);
 928:	8556                	mv	a0,s5
 92a:	00000097          	auipc	ra,0x0
 92e:	dc6080e7          	jalr	-570(ra) # 6f0 <putc>
          s++;
 932:	0905                	addi	s2,s2,1
        while(*s != 0){
 934:	00094583          	lbu	a1,0(s2)
 938:	f9e5                	bnez	a1,928 <vprintf+0x16c>
        s = va_arg(ap, char*);
 93a:	8b4e                	mv	s6,s3
      state = 0;
 93c:	4981                	li	s3,0
 93e:	bdf9                	j	81c <vprintf+0x60>
          s = "(null)";
 940:	00000917          	auipc	s2,0x0
 944:	3b890913          	addi	s2,s2,952 # cf8 <malloc+0x272>
        while(*s != 0){
 948:	02800593          	li	a1,40
 94c:	bff1                	j	928 <vprintf+0x16c>
        putc(fd, va_arg(ap, uint));
 94e:	008b0913          	addi	s2,s6,8
 952:	000b4583          	lbu	a1,0(s6)
 956:	8556                	mv	a0,s5
 958:	00000097          	auipc	ra,0x0
 95c:	d98080e7          	jalr	-616(ra) # 6f0 <putc>
 960:	8b4a                	mv	s6,s2
      state = 0;
 962:	4981                	li	s3,0
 964:	bd65                	j	81c <vprintf+0x60>
        putc(fd, c);
 966:	85d2                	mv	a1,s4
 968:	8556                	mv	a0,s5
 96a:	00000097          	auipc	ra,0x0
 96e:	d86080e7          	jalr	-634(ra) # 6f0 <putc>
      state = 0;
 972:	4981                	li	s3,0
 974:	b565                	j	81c <vprintf+0x60>
        s = va_arg(ap, char*);
 976:	8b4e                	mv	s6,s3
      state = 0;
 978:	4981                	li	s3,0
 97a:	b54d                	j	81c <vprintf+0x60>
    }
  }
}
 97c:	70e6                	ld	ra,120(sp)
 97e:	7446                	ld	s0,112(sp)
 980:	74a6                	ld	s1,104(sp)
 982:	7906                	ld	s2,96(sp)
 984:	69e6                	ld	s3,88(sp)
 986:	6a46                	ld	s4,80(sp)
 988:	6aa6                	ld	s5,72(sp)
 98a:	6b06                	ld	s6,64(sp)
 98c:	7be2                	ld	s7,56(sp)
 98e:	7c42                	ld	s8,48(sp)
 990:	7ca2                	ld	s9,40(sp)
 992:	7d02                	ld	s10,32(sp)
 994:	6de2                	ld	s11,24(sp)
 996:	6109                	addi	sp,sp,128
 998:	8082                	ret

000000000000099a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 99a:	715d                	addi	sp,sp,-80
 99c:	ec06                	sd	ra,24(sp)
 99e:	e822                	sd	s0,16(sp)
 9a0:	1000                	addi	s0,sp,32
 9a2:	e010                	sd	a2,0(s0)
 9a4:	e414                	sd	a3,8(s0)
 9a6:	e818                	sd	a4,16(s0)
 9a8:	ec1c                	sd	a5,24(s0)
 9aa:	03043023          	sd	a6,32(s0)
 9ae:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 9b2:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 9b6:	8622                	mv	a2,s0
 9b8:	00000097          	auipc	ra,0x0
 9bc:	e04080e7          	jalr	-508(ra) # 7bc <vprintf>
}
 9c0:	60e2                	ld	ra,24(sp)
 9c2:	6442                	ld	s0,16(sp)
 9c4:	6161                	addi	sp,sp,80
 9c6:	8082                	ret

00000000000009c8 <printf>:

void
printf(const char *fmt, ...)
{
 9c8:	711d                	addi	sp,sp,-96
 9ca:	ec06                	sd	ra,24(sp)
 9cc:	e822                	sd	s0,16(sp)
 9ce:	1000                	addi	s0,sp,32
 9d0:	e40c                	sd	a1,8(s0)
 9d2:	e810                	sd	a2,16(s0)
 9d4:	ec14                	sd	a3,24(s0)
 9d6:	f018                	sd	a4,32(s0)
 9d8:	f41c                	sd	a5,40(s0)
 9da:	03043823          	sd	a6,48(s0)
 9de:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 9e2:	00840613          	addi	a2,s0,8
 9e6:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 9ea:	85aa                	mv	a1,a0
 9ec:	4505                	li	a0,1
 9ee:	00000097          	auipc	ra,0x0
 9f2:	dce080e7          	jalr	-562(ra) # 7bc <vprintf>
}
 9f6:	60e2                	ld	ra,24(sp)
 9f8:	6442                	ld	s0,16(sp)
 9fa:	6125                	addi	sp,sp,96
 9fc:	8082                	ret

00000000000009fe <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 9fe:	1141                	addi	sp,sp,-16
 a00:	e422                	sd	s0,8(sp)
 a02:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a04:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a08:	00000797          	auipc	a5,0x0
 a0c:	5f87b783          	ld	a5,1528(a5) # 1000 <freep>
 a10:	a805                	j	a40 <free+0x42>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    bp->s.size += p->s.ptr->s.size;
 a12:	4618                	lw	a4,8(a2)
 a14:	9db9                	addw	a1,a1,a4
 a16:	feb52c23          	sw	a1,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a1a:	6398                	ld	a4,0(a5)
 a1c:	6318                	ld	a4,0(a4)
 a1e:	fee53823          	sd	a4,-16(a0)
 a22:	a091                	j	a66 <free+0x68>
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    p->s.size += bp->s.size;
 a24:	ff852703          	lw	a4,-8(a0)
 a28:	9e39                	addw	a2,a2,a4
 a2a:	c790                	sw	a2,8(a5)
    p->s.ptr = bp->s.ptr;
 a2c:	ff053703          	ld	a4,-16(a0)
 a30:	e398                	sd	a4,0(a5)
 a32:	a099                	j	a78 <free+0x7a>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a34:	6398                	ld	a4,0(a5)
 a36:	00e7e463          	bltu	a5,a4,a3e <free+0x40>
 a3a:	00e6ea63          	bltu	a3,a4,a4e <free+0x50>
{
 a3e:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a40:	fed7fae3          	bgeu	a5,a3,a34 <free+0x36>
 a44:	6398                	ld	a4,0(a5)
 a46:	00e6e463          	bltu	a3,a4,a4e <free+0x50>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a4a:	fee7eae3          	bltu	a5,a4,a3e <free+0x40>
  if(bp + bp->s.size == p->s.ptr){
 a4e:	ff852583          	lw	a1,-8(a0)
 a52:	6390                	ld	a2,0(a5)
 a54:	02059713          	slli	a4,a1,0x20
 a58:	9301                	srli	a4,a4,0x20
 a5a:	0712                	slli	a4,a4,0x4
 a5c:	9736                	add	a4,a4,a3
 a5e:	fae60ae3          	beq	a2,a4,a12 <free+0x14>
    bp->s.ptr = p->s.ptr;
 a62:	fec53823          	sd	a2,-16(a0)
  if(p + p->s.size == bp){
 a66:	4790                	lw	a2,8(a5)
 a68:	02061713          	slli	a4,a2,0x20
 a6c:	9301                	srli	a4,a4,0x20
 a6e:	0712                	slli	a4,a4,0x4
 a70:	973e                	add	a4,a4,a5
 a72:	fae689e3          	beq	a3,a4,a24 <free+0x26>
  } else
    p->s.ptr = bp;
 a76:	e394                	sd	a3,0(a5)
  freep = p;
 a78:	00000717          	auipc	a4,0x0
 a7c:	58f73423          	sd	a5,1416(a4) # 1000 <freep>
}
 a80:	6422                	ld	s0,8(sp)
 a82:	0141                	addi	sp,sp,16
 a84:	8082                	ret

0000000000000a86 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a86:	7139                	addi	sp,sp,-64
 a88:	fc06                	sd	ra,56(sp)
 a8a:	f822                	sd	s0,48(sp)
 a8c:	f426                	sd	s1,40(sp)
 a8e:	f04a                	sd	s2,32(sp)
 a90:	ec4e                	sd	s3,24(sp)
 a92:	e852                	sd	s4,16(sp)
 a94:	e456                	sd	s5,8(sp)
 a96:	e05a                	sd	s6,0(sp)
 a98:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a9a:	02051493          	slli	s1,a0,0x20
 a9e:	9081                	srli	s1,s1,0x20
 aa0:	04bd                	addi	s1,s1,15
 aa2:	8091                	srli	s1,s1,0x4
 aa4:	0014899b          	addiw	s3,s1,1
 aa8:	0485                	addi	s1,s1,1
  if((prevp = freep) == 0){
 aaa:	00000517          	auipc	a0,0x0
 aae:	55653503          	ld	a0,1366(a0) # 1000 <freep>
 ab2:	c515                	beqz	a0,ade <malloc+0x58>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ab4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ab6:	4798                	lw	a4,8(a5)
 ab8:	02977f63          	bgeu	a4,s1,af6 <malloc+0x70>
 abc:	8a4e                	mv	s4,s3
 abe:	0009871b          	sext.w	a4,s3
 ac2:	6685                	lui	a3,0x1
 ac4:	00d77363          	bgeu	a4,a3,aca <malloc+0x44>
 ac8:	6a05                	lui	s4,0x1
 aca:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 ace:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 ad2:	00000917          	auipc	s2,0x0
 ad6:	52e90913          	addi	s2,s2,1326 # 1000 <freep>
  if(p == (char*)-1)
 ada:	5afd                	li	s5,-1
 adc:	a88d                	j	b4e <malloc+0xc8>
    base.s.ptr = freep = prevp = &base;
 ade:	00000797          	auipc	a5,0x0
 ae2:	53278793          	addi	a5,a5,1330 # 1010 <base>
 ae6:	00000717          	auipc	a4,0x0
 aea:	50f73d23          	sd	a5,1306(a4) # 1000 <freep>
 aee:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 af0:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 af4:	b7e1                	j	abc <malloc+0x36>
      if(p->s.size == nunits)
 af6:	02e48b63          	beq	s1,a4,b2c <malloc+0xa6>
        p->s.size -= nunits;
 afa:	4137073b          	subw	a4,a4,s3
 afe:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b00:	1702                	slli	a4,a4,0x20
 b02:	9301                	srli	a4,a4,0x20
 b04:	0712                	slli	a4,a4,0x4
 b06:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b08:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b0c:	00000717          	auipc	a4,0x0
 b10:	4ea73a23          	sd	a0,1268(a4) # 1000 <freep>
      return (void*)(p + 1);
 b14:	01078513          	addi	a0,a5,16
      if((p = morecore(nunits)) == 0)
        return 0;
  }
}
 b18:	70e2                	ld	ra,56(sp)
 b1a:	7442                	ld	s0,48(sp)
 b1c:	74a2                	ld	s1,40(sp)
 b1e:	7902                	ld	s2,32(sp)
 b20:	69e2                	ld	s3,24(sp)
 b22:	6a42                	ld	s4,16(sp)
 b24:	6aa2                	ld	s5,8(sp)
 b26:	6b02                	ld	s6,0(sp)
 b28:	6121                	addi	sp,sp,64
 b2a:	8082                	ret
        prevp->s.ptr = p->s.ptr;
 b2c:	6398                	ld	a4,0(a5)
 b2e:	e118                	sd	a4,0(a0)
 b30:	bff1                	j	b0c <malloc+0x86>
  hp->s.size = nu;
 b32:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b36:	0541                	addi	a0,a0,16
 b38:	00000097          	auipc	ra,0x0
 b3c:	ec6080e7          	jalr	-314(ra) # 9fe <free>
  return freep;
 b40:	00093503          	ld	a0,0(s2)
      if((p = morecore(nunits)) == 0)
 b44:	d971                	beqz	a0,b18 <malloc+0x92>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b46:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b48:	4798                	lw	a4,8(a5)
 b4a:	fa9776e3          	bgeu	a4,s1,af6 <malloc+0x70>
    if(p == freep)
 b4e:	00093703          	ld	a4,0(s2)
 b52:	853e                	mv	a0,a5
 b54:	fef719e3          	bne	a4,a5,b46 <malloc+0xc0>
  p = sbrk(nu * sizeof(Header));
 b58:	8552                	mv	a0,s4
 b5a:	00000097          	auipc	ra,0x0
 b5e:	b56080e7          	jalr	-1194(ra) # 6b0 <sbrk>
  if(p == (char*)-1)
 b62:	fd5518e3          	bne	a0,s5,b32 <malloc+0xac>
        return 0;
 b66:	4501                	li	a0,0
 b68:	bf45                	j	b18 <malloc+0x92>
