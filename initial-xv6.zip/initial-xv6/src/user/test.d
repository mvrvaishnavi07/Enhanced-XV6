user/test.o: user/test.c kernel/param.h kernel/types.h kernel/stat.h \
 kernel/riscv.h user/user.h
